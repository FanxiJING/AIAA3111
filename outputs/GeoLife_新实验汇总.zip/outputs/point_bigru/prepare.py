"""Prepare unsegmented, variable-length GeoLife sequences using the point baseline's ordering."""
from pathlib import Path
import sys

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent / "point_window_comparison"))
from run import DEFAULT_SPLITS, MODES, POINT_FEATURES, load_split, load_user, point_features


def prepare_user(uid, expected_points, cache):
    points = load_user(uid)
    assert len(points) == expected_points and points["user_id"].eq(uid).all(), uid
    assert points["timestamp"].notna().all() and points["feature_block_id"].notna().all(), uid
    x = np.ascontiguousarray(point_features(points).to_numpy(dtype=np.float32))
    y = pd.Categorical(points["mode"], categories=MODES).codes.astype(np.int8)
    t = points["timestamp"].to_numpy(dtype="datetime64[s]").astype(np.int64)
    block = points["feature_block_id"].to_numpy()
    same = block[1:] == block[:-1]
    first = np.r_[0, np.flatnonzero(~same) + 1]
    lengths = np.diff(np.r_[first, len(points)])
    assert x.shape == (len(points), len(POINT_FEATURES)) and not np.isinf(x).any(), uid
    assert np.all(y >= 0) and np.all((t[1:] > t[:-1])[same]), uid
    assert len(first) == points["feature_block_id"].nunique(), uid
    assert lengths.sum() == expected_points and np.all(lengths > 0), uid
    out = cache / f"{uid}.npz"
    tmp = out.with_suffix(".tmp")
    with tmp.open("wb") as stream:
        np.savez(stream, x=x, y=y, t=t, lengths=lengths)
    tmp.replace(out)
    return len(lengths), len(points)


def main():
    cache = OUT / "cache"
    cache.mkdir(exist_ok=True)
    manifest = pd.read_csv(DEFAULT_SPLITS / "manifest.csv", dtype={"user_id": str}).set_index("user_id")
    split = load_split(DEFAULT_SPLITS)
    assert manifest.index.is_unique and manifest["split"].to_dict() == split
    assert list(manifest["split"].value_counts().reindex(["train", "test"])) == [51, 13]
    for name in ("train", "test"):
        blocks = n = 0
        for uid in sorted(u for u, which in split.items() if which == name):
            b, count = prepare_user(uid, int(manifest.loc[uid, "points"]), cache)
            blocks += b
            n += count
        print(f"{name}: {n:,} points; {blocks:,} full blocks", flush=True)
    assert len(list(cache.glob("*.npz"))) == len(split) == 64


if __name__ == "__main__":
    main()
