"""Train offline bidirectional GRU sequence tagging and a matched context-reset control.

Run prepare.py with pyarrow first. This script requires numpy and PyTorch.
"""
import copy
import json
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torch.nn.utils.rnn import pad_sequence

OUT = Path(__file__).resolve().parent
SPLITS = OUT.parents[1] / "data" / "splits"
SEED = 42
HIDDEN = 24
EPOCHS = 8
FEATURES = ["distance_m", "speed_mps", "acceleration_mps2", "jerk_mps3",
            "heading_change_rad", "heading_change_rate_rad_s"]
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def select_users(users, held_out):
    # Choose a validation group representing all modes, using training labels only.
    counts = []
    for user in users:
        with np.load(OUT / "cache" / f"{user}.npz") as data:
            counts.append(np.bincount(data["y"].astype(int), minlength=5))
    counts = np.stack(counts)
    groups = {u: u for u in users}
    for i, linked in enumerate(read_json(SPLITS / "report.json")["duplicate_linked_groups"]):
        assert not (set(linked) & set(users) and set(linked) & set(held_out))
        for u in set(linked) & set(users):
            groups[u] = f"linked-{i}"
    group_ids = np.array([groups[u] for u in users])
    unique = np.unique(group_ids)
    rng = np.random.default_rng(SEED)
    best = np.inf
    for _ in range(1000):
        mask = np.isin(group_ids, rng.choice(unique, round(len(unique) * 0.16), replace=False))
        fraction = counts[mask].sum(axis=0) / counts.sum(axis=0)
        error = np.square(fraction - 0.16).mean()
        if error < best:
            best, selected = error, mask.copy()
    return ([u for u, val in zip(users, selected) if not val],
            [u for u, val in zip(users, selected) if val])


def load_blocks(users, subset=False):
    rng = np.random.default_rng(SEED + 1)
    blocks = []
    for uid in users:
        with np.load(OUT / "cache" / f"{uid}.npz") as data:
            x, y, lengths = data["x"], data["y"], data["lengths"]
        boundaries = np.r_[0, np.cumsum(lengths)]
        indices = np.arange(len(lengths))
        if subset:
            n = max(1, round(len(indices) / 8))
            indices = np.sort(rng.choice(indices, size=n, replace=False))
        for i in indices:
            region = slice(boundaries[i], boundaries[i + 1])
            blocks.append((x[region].copy(), y[region].astype(np.int64)))
    return blocks


def log_features(x):
    x = np.where(np.isfinite(x), x, np.nan)
    return np.sign(x) * np.log1p(np.abs(x))


def standardize(blocks, mean, std):
    return [(torch.from_numpy(np.nan_to_num((log_features(x) - mean) / std, nan=0.0)),
             torch.from_numpy(y)) for x, y in blocks]


class PointTagger(nn.Module):
    """Two GRU directions; reverse only real samples, leaving padding after each sequence."""
    def __init__(self):
        super().__init__()
        self.forward_gru = nn.GRU(len(FEATURES), HIDDEN, batch_first=True)
        self.backward_gru = nn.GRU(len(FEATURES), HIDDEN, batch_first=True)
        self.classifier = nn.Linear(2 * HIDDEN, 5)

    def forward(self, x, lengths, reset=False):
        if reset:
            # Each point is a separate sequence of length one in both directions.
            flat = x.reshape(-1, 1, x.size(-1))
            outputs = []
            for part in flat.split(4096):
                fwd, _ = self.forward_gru(part)
                bwd, _ = self.backward_gru(part)
                outputs.append(self.classifier(torch.cat((fwd, bwd), dim=-1)))
            return torch.cat(outputs).reshape(*x.shape[:2], 5)
        index = (lengths[:, None] - 1 - torch.arange(x.size(1), device=x.device)).clamp_min(0)
        backwards = x.gather(1, index[..., None].expand_as(x))
        fwd, _ = self.forward_gru(x)
        bwd, _ = self.backward_gru(backwards)
        bwd = bwd.gather(1, index[..., None].expand_as(bwd))
        return self.classifier(torch.cat((fwd, bwd), dim=-1))


def batches(blocks, rng=None):
    lengths = np.array([len(y) for x, y in blocks])
    order = lengths if rng is None else lengths * rng.uniform(0.9, 1.1, len(lengths))
    groups, group, longest = [], [], 0
    for i in np.argsort(order):
        size = int(lengths[i])
        if group and (max(longest, size) * (len(group) + 1) > 24576 or len(group) >= 128):
            groups.append(group)
            group, longest = [], 0
        group.append(i)
        longest = max(longest, size)
    if group:
        groups.append(group)
    if rng is not None:
        rng.shuffle(groups)
    return groups


def tensor_batch(blocks, group):
    xs, ys = zip(*(blocks[i] for i in group))
    return (pad_sequence(xs, batch_first=True).to(DEVICE),
            pad_sequence(ys, batch_first=True, padding_value=-100).to(DEVICE),
            torch.tensor([len(y) for y in ys], device=DEVICE))


@torch.no_grad()
def evaluate(models, blocks, predict=False):
    matrices = np.zeros((2, 5, 5), dtype=np.int64)
    predictions = [[None] * len(blocks) for model in models] if predict else None
    for group in batches(blocks):
        x, y, lengths = tensor_batch(blocks, group)
        valid = y != -100
        for i, model in enumerate(models):
            model.eval()
            pred = model(x, lengths, reset=bool(i)).argmax(-1)
            codes = (y[valid] * 5 + pred[valid]).cpu().numpy()
            matrices[i] += np.bincount(codes, minlength=25).reshape(5, 5)
            if predict:
                arr = pred.cpu().numpy().astype(np.uint8)
                for row, index in enumerate(group):
                    predictions[i][index] = arr[row, :len(blocks[index][1])].copy()
    denom = matrices.sum(1) + matrices.sum(2)
    scores = (2 * np.diagonal(matrices, axis1=1, axis2=2) / denom.clip(1)).mean(1)
    return scores, predictions


def check_model(model):
    # Valid logits must be invariant to padding and to which other blocks share a batch.
    x = torch.randn(2, 13, len(FEATURES), device=DEVICE)
    lengths = torch.tensor([5, 13], device=DEVICE)
    with torch.no_grad():
        for reset in [False, True]:
            pred = model(x, lengths, reset=reset)
            single = model(x[:1, :5], lengths[:1], reset=reset)
            torch.testing.assert_close(pred[:1, :5], single, atol=2e-5, rtol=2e-4)
        single = model(x[:1, 3:4], torch.ones(1, device=DEVICE, dtype=torch.long), reset=True)
        torch.testing.assert_close(single, pred[:1, 3:4], atol=2e-5, rtol=2e-4)


def main():
    torch.manual_seed(SEED)
    torch.set_num_threads(3)
    rng = np.random.default_rng(SEED)
    test_users = sorted(read_json(SPLITS / "test_users.json"))
    fit_users, val_users = select_users(sorted(read_json(SPLITS / "train_users.json")), test_users)
    raw = load_blocks(fit_users, subset=True)
    stacked = log_features(np.concatenate([x for x, y in raw]))
    mean = np.nanmean(stacked, axis=0, dtype=np.float64).astype(np.float32)
    std = np.nanstd(stacked, axis=0, dtype=np.float64).clip(1e-6).astype(np.float32)
    counts = np.bincount(np.concatenate([y for x, y in raw]), minlength=5)
    weights = torch.tensor(np.sqrt(counts.sum() / (5 * counts)), dtype=torch.float32, device=DEVICE)
    train = standardize(raw, mean, std)
    del raw, stacked
    val = standardize(load_blocks(val_users), mean, std)
    model = PointTagger().to(DEVICE)
    check_model(model)
    models = [model, copy.deepcopy(model)]
    optimizers = [torch.optim.Adam(m.parameters(), lr=0.003) for m in models]
    print(f"{DEVICE}: {len(train)} training blocks / {counts.sum()} points; "
          f"{len(val_users)} validation users / {sum(len(y) for x, y in val)} points", flush=True)
    best = [-1., -1.]
    epochs = [None, None]
    history = []
    checkpoints = [OUT / "bigru.pt", OUT / "reset_control.pt"]
    for epoch in range(1, EPOCHS + 1):
        start = time.perf_counter()
        for m in models:
            m.train()
        group_list = batches(train, rng)
        for j, group in enumerate(group_list):
            x, y, lengths = tensor_batch(train, group)
            for i, (m, opt) in enumerate(zip(models, optimizers)):
                opt.zero_grad(set_to_none=True)
                logits = m(x, lengths, reset=bool(i))
                loss = F.cross_entropy(logits.reshape(-1, 5), y.reshape(-1), weight=weights)
                if not torch.isfinite(loss):
                    raise ValueError("Nonfinite training loss")
                loss.backward()
                nn.utils.clip_grad_norm_(m.parameters(), 5.)
                opt.step()
            if epoch == 1 and j % 12 == 0:
                print(f"Training batch {j + 1}/{len(group_list)}", flush=True)
        scores, _ = evaluate(models, val)
        for i, s in enumerate(scores):
            if s > best[i]:
                best[i], epochs[i] = float(s), epoch
                torch.save(models[i].state_dict(), checkpoints[i])
        history.append({"epoch": epoch, "bigru_val_macro_f1": float(scores[0]),
                        "control_val_macro_f1": float(scores[1])})
        print(f"Epoch {epoch}/{EPOCHS}: validation Macro-F1 {scores.round(4)}, "
              f"{time.perf_counter() - start:.1f}s", flush=True)
    info = dict(fit_users=fit_users, val_users=val_users, test_users=test_users,
                train_points=int(counts.sum()), train_blocks=len(train), val_points=sum(len(y) for x, y in val),
                best_epoch=epochs[0], control_best_epoch=epochs[1], history=history,
                feature_names=FEATURES, hidden_size=HIDDEN, seed=SEED, train_class_counts=counts.tolist(),
                device=str(DEVICE), torch_version=str(torch.__version__), mean=mean.tolist(), std=std.tolist(),
                train_subset_note="Per fitting user, a seeded random 1/8 of whole natural blocks (at least one).",
                preprocessing="Signed log1p, fit-subset mean and SD, missing mapped to centered zero.",
                selection="Highest validation point-level macro-F1 for each model over 8 epochs, first tie.")
    (OUT / "training.json").write_text(json.dumps(info, indent=2), encoding="utf-8")
    for m, path in zip(models, checkpoints):
        m.load_state_dict(torch.load(path, weights_only=True, map_location=DEVICE))
    directory = OUT / "predictions"
    directory.mkdir(exist_ok=True)
    for uid in test_users:
        test = standardize(load_blocks([uid]), mean, std)
        _, predictions = evaluate(models, test, predict=True)
        with np.load(OUT / "cache" / f"{uid}.npz") as data:
            np.savez_compressed(directory / f"{uid}.npz", pred=np.concatenate(predictions[0]),
                                control_pred=np.concatenate(predictions[1]), y=data["y"], t=data["t"])
        print(f"Scored user {uid}", flush=True)


if __name__ == "__main__":
    main()
