"""Score offline point labels against the original, block-ordered test trajectories."""

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
BASELINE = OUT.parent / "point_window_comparison"
sys.path.insert(0, str(BASELINE))
from run import DEFAULT_SPLITS, MODES, TOLERANCES, event_counts, load_split, load_user
from models import cv_groups, metrics_from_cm

FIELDS = {"BiGRU": "pred", "point_control": "control_pred"}
NAMES = {"BiGRU": "逐点 BiGRU（整块上下文）", "point_control": "逐点神经网络（每点重置状态）",
         "point": "逐点 SVM", "W25": "25 点窗 SVM", "W50": "50 点窗 SVM"}
N_MODES = len(MODES)


def score_row(matrix, true, predicted, hits):
    metrics = metrics_from_cm(matrix)
    return {
        "test_points": int(matrix.sum()), "macro_f1": metrics["macro_f1"],
        "accuracy": metrics["accuracy"], "true_events": int(true),
        "predicted_events": int(predicted), "matched_events": int(hits),
        "transition_precision": hits / predicted if predicted else 0.0,
        "transition_recall": hits / true if true else 0.0,
        "transition_f1": 2 * hits / (true + predicted) if true + predicted else 0.0,
    }


def score_users(users):
    rows, matrices = [], {model: {} for model in FIELDS}
    for uid in users:
        points = load_user(uid)
        times = points["timestamp"].to_numpy(dtype="datetime64[s]").astype(np.int64)
        truth = pd.Categorical(points["mode"], categories=MODES).codes.astype(np.int64)
        assert (truth >= 0).all()
        with np.load(OUT / "predictions" / f"{uid}.npz", allow_pickle=False) as saved:
            np.testing.assert_array_equal(saved["t"], times, err_msg=f"{uid} test timestamps")
            np.testing.assert_array_equal(saved["y"], truth, err_msg=f"{uid} test labels")
            for model, field in FIELDS.items():
                pred = saved[field]
                assert pred.shape == truth.shape and np.issubdtype(pred.dtype, np.integer)
                assert np.all((pred >= 0) & (pred < N_MODES))
                matrix = np.bincount(truth * N_MODES + pred, minlength=N_MODES ** 2)
                matrix = matrix.reshape(N_MODES, N_MODES)
                matrices[model][uid] = matrix
                # Align the boundary to the first point of the newly predicted mode.
                # For BiGRU this is retrospective localization; future points are used.
                counts = event_counts(points, pred, times)
                for tol, (true, predicted, hits, _) in counts.items():
                    rows.append({"configuration": model, "user_id": uid, "tolerance_s": tol,
                                 **score_row(matrix, true, predicted, hits)})
    return pd.DataFrame(rows), matrices


def paired_intervals(users, matrices, by_user):
    """Paired percentile bootstrap, resampling linked test users as one group."""
    user_groups = cv_groups(pd.Series(users), DEFAULT_SPLITS / "report.json").to_numpy()
    groups = np.unique(user_groups)
    assert len(groups) == 9
    rng = np.random.default_rng(42)
    group_weights = rng.multinomial(len(groups), np.ones(len(groups)) / len(groups), size=5000)
    event_keys = ["true_events", "predicted_events", "matched_events"]
    scores = {}
    for model in FIELDS:
        user_cm = np.stack([matrices[model][uid] for uid in users])
        events = by_user.query("configuration == @model and tolerance_s == 60").set_index("user_id")
        events = events.loc[users, event_keys].to_numpy()
        grouped_cm = np.stack([user_cm[user_groups == group].sum(0) for group in groups])
        grouped_events = np.stack([events[user_groups == group].sum(0) for group in groups])
        sampled_cm = (group_weights @ grouped_cm.reshape(len(groups), -1)).reshape(-1, N_MODES, N_MODES)
        true, predicted, hits = (group_weights @ grouped_events).T
        diag = np.diagonal(sampled_cm, axis1=1, axis2=2)
        denom = sampled_cm.sum(1) + sampled_cm.sum(2)
        f1 = np.divide(2 * diag, denom, out=np.zeros_like(diag, dtype=float), where=denom > 0)
        transition = np.divide(2 * hits, true + predicted, out=np.zeros_like(hits, dtype=float),
                               where=true + predicted > 0)
        scores[model] = np.column_stack((f1.mean(1), transition))
    return np.quantile(scores["BiGRU"] - scores["point_control"], [0.025, 0.975], axis=0)


def report(summary, meta, intervals):
    table = summary.loc[summary.tolerance_s == 60].set_index("configuration")
    lines = ["# GeoLife 离线逐点序列标注", "", "## 固定测试集结果", "",
             "下表按 GPS 点的时间定位切换，容差为 ±60 秒。在同一轨迹块内对真实与预测切换做一对一匹配，匹配只要求发生切换。BiGRU 使用目标点前后的上下文，表中时间衡量离线定位精度。窗口模型的边界对齐到新类别窗口的首点。", "",
             "| 模型 | 点级 Macro-F1 | 准确率 | 切换精确率 | 切换召回率 | 切换 F1 | 匹配数 | 预测切换数 |",
             "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for model in NAMES:
        r = table.loc[model]
        lines.append(f"| {NAMES[model]} | {r.macro_f1:.4f} | {r.accuracy:.2%} | "
                     f"{r.transition_precision:.2%} | {r.transition_recall:.2%} | "
                     f"{r.transition_f1:.4f} | {int(r.matched_events):,} | {int(r.predicted_events):,} |")
    delta = table.loc["BiGRU", ["macro_f1", "transition_f1"]] - table.loc["point_control", ["macro_f1", "transition_f1"]]
    lines.extend(["", f"相对每点重置状态的神经网络对照，BiGRU 的点级 Macro-F1 差值为 {delta.macro_f1:+.4f}"
                  f"（配对 95% 区间 {intervals[0,0]:+.4f} 至 {intervals[1,0]:+.4f}），切换 F1 差值为 "
                  f"{delta.transition_f1:+.4f}（{intervals[0,1]:+.4f} 至 {intervals[1,1]:+.4f}）。"
                  "区间按 9 个独立测试用户组配对重抽样 5,000 次，仅反映这组已训练模型的测试用户差异。",
                  "", "## 切换 F1 对容差的敏感性", "",
                  "| 模型 | ±30 秒 | ±60 秒 | ±120 秒 |", "|---|---:|---:|---:|"])
    sensitivity = summary.pivot(index="configuration", columns="tolerance_s", values="transition_f1")
    for model in NAMES:
        lines.append("| " + NAMES[model] + " | " + " | ".join(f"{sensitivity.loc[model, tol]:.4f}" for tol in TOLERANCES) + " |")
    lines.extend(["", "## 实验范围", "",
                  f"- 两个神经网络采用相同的输入字段和训练数据，训练数据共 {meta['train_points']:,} 个点、"
                  f"{meta['train_blocks']:,} 个完整轨迹块。验证集有 {meta['val_points']:,} 个点。"
                  f"BiGRU 选中第 {meta['best_epoch']} 轮，每点重置状态的对照选中第 {meta['control_best_epoch']} 轮。",
                  f"- 共 {len(meta['fit_users'])} 位用户用于拟合，{len(meta['val_users'])} 位用户用于验证。"
                  f"训练用户各自按固定种子抽取约八分之一的完整轨迹块，每人至少一块。各模型按 "
                  f"{len(meta['history'])} 轮中的验证集点级 Macro-F1 选择轮次。",
                  f"- 输入字段为 {', '.join(meta['feature_names'])}。每个方向的隐藏状态维数为 {meta['hidden_size']}。"
                  "每个点输出一个类别，相邻预测类别不同形成切换。序列上下文在轨迹块边界处重置。",
                  f"- 测试包含 {len(meta['test_users'])} 位用户、860,972 个 GPS 点和 658 个真实切换点。"
                  "新的神经网络结果采用相同测试点和同一组逐点标签，与三个已保存的 SVM 结果并列。"
                  "SVM 与神经网络使用的训练样本、模型配方有所不同。样本选择和轮次记录见 [training.json](training.json)。",
                  "- 完整指标见 [results.csv](results.csv)，两个神经网络的逐用户和分类别结果见 "
                  "[per_user.csv](per_user.csv) 和 [per_class.csv](per_class.csv)。", ""])
    (OUT / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def main():
    meta = json.loads((OUT / "training.json").read_text(encoding="utf-8"))
    users = sorted(uid for uid, role in load_split(DEFAULT_SPLITS).items() if role == "test")
    assert sorted(str(u).zfill(3) for u in meta["test_users"]) == users
    assert set(meta["fit_users"]).isdisjoint(meta["val_users"])
    assert set(users).isdisjoint(str(u).zfill(3) for u in [*meta["fit_users"], *meta["val_users"]])
    by_user, matrices = score_users(users)
    baseline = pd.read_csv(BASELINE / "results.csv").query("timing == 'window_start'").copy()
    baseline_users = pd.read_csv(BASELINE / "per_user.csv", dtype={"user_id": str})
    expected = (baseline_users.query("configuration == 'point' and tolerance_s == 60")
                .set_index("user_id").sort_index()[["test_points", "true_events"]])
    rows, per_class = [], []
    for model in FIELDS:
        matrix = np.sum(list(matrices[model].values()), axis=0)
        for label, count, f1 in zip(MODES, matrix.sum(axis=1), metrics_from_cm(matrix)["per_class_f1"]):
            per_class.append({"configuration": model, "mode": label, "test_points": int(count), "f1": f1})
        for tol in TOLERANCES:
            part = by_user.query("configuration == @model and tolerance_s == @tol").set_index("user_id").sort_index()
            pd.testing.assert_frame_equal(part[expected.columns], expected, check_dtype=False)
            rows.append({"configuration": model, "train_rows": meta["train_points"], "tolerance_s": tol,
                         **score_row(matrix, part.true_events.sum(), part.predicted_events.sum(), part.matched_events.sum())})
    summary = pd.concat([pd.DataFrame(rows), baseline], ignore_index=True)
    summary["timing"] = "retrospective_point_time"
    assert (summary.test_points == 860_972).all() and (summary.true_events == 658).all()
    assert not summary.duplicated(["configuration", "tolerance_s"]).any()
    assert len(summary) == len(NAMES) * len(TOLERANCES)
    intervals = paired_intervals(users, matrices, by_user)
    summary.to_csv(OUT / "results.csv", index=False)
    by_user.to_csv(OUT / "per_user.csv", index=False)
    pd.DataFrame(per_class).to_csv(OUT / "per_class.csv", index=False)
    report(summary, meta, intervals)
    print(summary.loc[summary.tolerance_s == 60].to_string(index=False))


if __name__ == "__main__":
    main()
