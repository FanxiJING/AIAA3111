"""Export matched raw GPS features and 48-dimensional vectors from the frozen BiGRU."""
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import torch
from sklearn.model_selection import train_test_split

OUT = Path(__file__).resolve().parent
PILOT = OUT.parent / "point_bigru"
sys.path.insert(0, str(PILOT))
from train import DEVICE, HIDDEN, batches, load_blocks, standardize, tensor_batch

SAMPLE = 70_000
SEED = 42


@torch.inference_mode()
def encode(model, blocks, mean, std):
    encoded = standardize(blocks, mean, std)
    offsets = np.r_[0, np.cumsum([len(y) for _, y in blocks])]
    vectors = np.empty((offsets[-1], 2 * HIDDEN), dtype=np.float32)
    predictions = np.empty(offsets[-1], dtype=np.uint8)
    layer_input = []

    def capture_input(module, inputs):
        layer_input.append(inputs[0].detach().cpu().numpy())

    handle = model.classifier.register_forward_pre_hook(capture_input)
    try:
        for group in batches(encoded):
            x, _, lengths = tensor_batch(encoded, group)
            pred = model(x, lengths).argmax(-1).cpu().numpy()
            hidden, = layer_input
            layer_input.clear()
            for row, i in enumerate(group):
                start, stop = offsets[i:i + 2]
                vectors[start:stop] = hidden[row, :stop - start]
                predictions[start:stop] = pred[row, :stop - start]
    finally:
        handle.remove()
    assert np.isfinite(vectors).all()
    return vectors, predictions


def main():
    from train import PointTagger

    payload = json.loads((PILOT / "training.json").read_text(encoding="utf-8"))
    fit, val, test = (payload[k] for k in ("fit_users", "val_users", "test_users"))
    assert not (set(fit) & set(val) or set(fit) & set(test) or set(test) & set(val))
    torch.set_num_threads(3)
    model = PointTagger().to(DEVICE)
    checkpoint = PILOT / "bigru.pt"
    model.load_state_dict(torch.load(checkpoint, map_location=DEVICE, weights_only=True))
    model.eval()
    mean, std = [np.asarray(payload[k], dtype=np.float32) for k in ("mean", "std")]

    features = OUT / "features"
    features.mkdir(exist_ok=True)
    train_blocks = load_blocks(fit, subset=True)
    train_x = np.concatenate([x for x, _ in train_blocks])
    train_y = np.concatenate([y for _, y in train_blocks])
    assert len(train_y) == payload["train_points"] and len(train_blocks) == payload["train_blocks"]
    np.testing.assert_array_equal(np.bincount(train_y, minlength=5), payload["train_class_counts"])
    train_z, _ = encode(model, train_blocks, mean, std)
    picked, _ = train_test_split(np.arange(len(train_y)), train_size=SAMPLE,
                                  stratify=train_y, random_state=SEED)
    picked.sort()
    np.savez(features / "train.npz", raw=train_x[picked], hidden=train_z[picked],
             y=train_y[picked], sample_indices=picked)
    print(f"Matched sample: {len(picked):,} of {len(train_y):,} original encoder training points", flush=True)
    for role, users in (("validation", val), ("test", test)):
        for uid in users:
            with np.load(PILOT / "cache" / f"{uid}.npz") as data:
                x, y, t, lengths = [data[k] for k in ("x", "y", "t", "lengths")]
            edges = np.r_[0, lengths.cumsum()]
            blocks = [(x[a:b], y[a:b].astype(np.int64)) for a, b in zip(edges[:-1], edges[1:])]
            hidden, pred = encode(model, blocks, mean, std)
            if role == "test":
                with np.load(PILOT / "predictions" / f"{uid}.npz") as data:
                    for key, actual in (("pred", pred), ("y", y), ("t", t)):
                        np.testing.assert_array_equal(actual, data[key], err_msg=f"{uid}: {key}")
            np.savez(features / f"{uid}.npz", raw=x, hidden=hidden, y=y, t=t, lengths=lengths,
                     prior_head=pred)
            print(f"{role}: {uid}, {len(y):,} verified points", flush=True)

    (OUT / "features.json").write_text(json.dumps({
        "fit_users": fit, "validation_users": val, "test_users": test,
        "seed": SEED, "sample_points": SAMPLE, "encoder_training_points": int(len(train_y)),
        "sample_class_counts": np.bincount(train_y[picked], minlength=5).tolist(),
        "checkpoint_sha256": hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
        "encoder_device": str(DEVICE),
        "raw_dim": train_x.shape[1], "bigru_dim": train_z.shape[1],
    }, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
