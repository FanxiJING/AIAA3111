"""Matched 2x2 point classification experiment with validation-only smoothing selection."""
import argparse
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.model_selection import train_test_split
from threadpoolctl import threadpool_limits

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent / "point_bigru"))
from score import TOLERANCES, score_row
from run import MODES, match_events
from pipeline_v2 import SVM_NAMES, class_scores, model_specs

REPRESENTATIONS = ("raw", "hidden")
CLASSIFIERS = ("svm", "rf")
RADII = (0, 5, 10, 20, 30, 60, 120)
PRIMARY = 60
MAX_MACRO_F1_DROP = 0.01
FEATURES = OUT / "features"


def fit(representation, classifier, x, y, smoke=False):
    label = SVM_NAMES[1] if classifier == "svm" else "Random Forest"
    model = model_specs(x.shape[1])[label].make(True)
    if classifier == "svm":
        model.set_params(clf__C=1.0, verbose=True)
        if smoke:
            model.set_params(rbf__n_components=32)
    else:
        model.set_params(clf__max_features="sqrt", clf__min_samples_leaf=5,
                         clf__n_jobs=4, clf__n_estimators=10 if smoke else 200)
    started = time.perf_counter()
    print(f"Fit {representation}/{classifier}: {x.shape}", flush=True)
    model.fit(x.astype(np.float64), np.asarray(MODES)[y])
    print(f"Fit {representation}/{classifier} took {time.perf_counter()-started:.1f}s", flush=True)
    return model


def predict_scores(model, x):
    """Use the stored SVM coefficients to avoid materializing all 1,000 features at inference."""
    if "rbf" not in model.named_steps:
        return class_scores(model, x)
    steps = model.named_steps
    kernel, classifier = steps["rbf"], steps["clf"]
    weights = kernel.normalization_.T @ classifier.coef_.T
    order = [list(classifier.classes_).index(c) for c in MODES]
    output = np.empty((len(x), len(MODES)), dtype=np.float64)
    for a in range(0, len(x), 16_384):
        b = min(a + 16_384, len(x))
        scaled = steps["scale"].transform(steps["impute"].transform(x[a:b].astype(np.float64)))
        design = rbf_kernel(scaled, kernel.components_, gamma=kernel.gamma)
        output[a:b] = (design @ weights + classifier.intercept_)[:, order]
    return output


def transitions(labels, time):
    return time[np.flatnonzero(labels[1:] != labels[:-1]) + 1]


def average_within_seconds(scores, times, radius):
    a = np.searchsorted(times, times - radius, side="left")
    b = np.searchsorted(times, times + radius, side="right")
    prefix = np.r_[np.zeros((1, len(MODES))), np.cumsum(scores, axis=0, dtype=np.float64)]
    return (prefix[b] - prefix[a]).argmax(axis=1)


def evaluate(models, settings, users, split):
    matrices = {s: np.zeros((5, 5), dtype=np.int64) for s in settings}
    totals = {s: np.zeros(2 + len(TOLERANCES), dtype=np.int64) for s in settings}
    per_user = []
    for uid in users:
        with np.load(FEATURES / f"{uid}.npz") as data:
            truth, times, lengths = (data[k] for k in ("y", "t", "lengths"))
            edges = np.r_[0, lengths.cumsum()]
            scores = {(rep, clf): predict_scores(models[(rep, clf)], data[rep])
                      for rep, clf in models}
            prior_head = data["prior_head"]
        assert edges[-1] == len(truth)
        for s in settings:
            rep, clf, radius = s
            values = scores[(rep, clf)] if clf != "linear_original" else None
            raw = prior_head if values is None else values.argmax(axis=1)
            pred = raw.copy()
            counts = np.zeros(2 + len(TOLERANCES), dtype=np.int64)
            for a, b in zip(edges[:-1], edges[1:]):
                time_block = times[a:b]
                if radius:
                    pred[a:b] = average_within_seconds(values[a:b], time_block, radius)
                actual = transitions(truth[a:b], time_block)
                proposed = transitions(pred[a:b], time_block)
                counts += (len(actual), len(proposed),
                           *(match_events(actual, proposed, tol) for tol in TOLERANCES))
            matrix = np.bincount(truth.astype(np.int64) * 5 + pred, minlength=25).reshape(5, 5)
            matrices[s] += matrix
            totals[s] += counts
            per_user.extend(rows(s, matrix, counts, user_id=uid))
        print(f"{split}: {uid}, {len(truth):,} points", flush=True)
    return (pd.DataFrame([row for s in settings for row in rows(s, matrices[s], totals[s])]),
            pd.DataFrame(per_user))


def rows(setting, matrix, counts, **extra):
    rep, clf, radius = setting
    return [dict(representation=rep, classifier=clf, radius_s=radius,
                 tolerance_s=tol, **extra, **score_row(matrix, *counts[:2], hits))
            for tol, hits in zip(TOLERANCES, counts[2:])]


def choose(validation):
    matched = validation.query("tolerance_s == @PRIMARY and representation == 'hidden' and classifier != 'linear_original'")
    unprocessed = matched.loc[matched["radius_s"].eq(0)].set_index("classifier")
    eligible = matched.loc[
        (matched["radius_s"] > 0)
        & (matched["macro_f1"] >= matched["classifier"].map(unprocessed["macro_f1"]) - MAX_MACRO_F1_DROP)
        & (matched["transition_f1"] > matched["classifier"].map(unprocessed["transition_f1"]))
    ].sort_values(["transition_f1", "radius_s", "classifier"], ascending=[False, True, True])
    if eligible.empty:
        return None
    best = eligible.iloc[0]
    return ("hidden", best["classifier"], int(best["radius_s"]))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--smoke", action="store_true")
    mode.add_argument("--reuse-models", action="store_true")
    args = parser.parse_args()
    meta = json.loads((OUT / "features.json").read_text(encoding="utf-8"))
    config = [(r, c) for r in REPRESENTATIONS for c in CLASSIFIERS]
    models = {}
    model_dir = OUT / "models"
    if not args.smoke:
        model_dir.mkdir(exist_ok=True)
    with np.load(FEATURES / "train.npz") as train:
        truth = train["y"]
        np.testing.assert_equal(len(np.unique(train["sample_indices"])), meta["sample_points"])
        domain = train_test_split(np.arange(len(truth)), train_size=512, stratify=truth, random_state=42)[0] if args.smoke else slice(None)
        for representation, classifier in config:
            key = (representation, classifier)
            path = model_dir / f"{representation}_{classifier}.joblib"
            features = train[representation][domain]
            models[key] = joblib.load(path) if args.reuse_models else fit(*key, features, truth[domain], args.smoke)
            if not (args.reuse_models or args.smoke):
                joblib.dump(models[key], path, compress=1)
            pilot = features[:256].astype(np.float64)
            fast = predict_scores(models[key], pilot)
            np.testing.assert_allclose(fast, class_scores(models[key], pilot), atol=1e-8, rtol=1e-7)
            np.testing.assert_array_equal(np.asarray(MODES)[fast.argmax(axis=1)], models[key].predict(pilot))
    baseline = ("hidden", "linear_original", 0)
    controls = [(rep, clf, 0) for rep, clf in config] + [baseline]
    candidates = controls + [("hidden", clf, r) for clf in CLASSIFIERS for r in RADII[1:]]
    val_users = meta["validation_users"][:1] if args.smoke else meta["validation_users"]
    validation, _ = evaluate(models, candidates, val_users, "validation")
    selected = choose(validation)
    test_users = meta["test_users"][:1] if args.smoke else meta["test_users"]
    if not args.smoke:
        assert (validation["test_points"] == 488_822).all()
        np.testing.assert_allclose(validation.query("classifier == 'linear_original'")["macro_f1"],
                                   0.6442661537946719)
        validation.to_csv(OUT / "validation.csv", index=False)
        (OUT / "selection.json").write_text(json.dumps({
            "selected": selected,
            "primary_tolerance_s": PRIMARY,
            "allowed_validation_macro_f1_drop": MAX_MACRO_F1_DROP,
            "smoothing_radius_s": list(RADII),
            "selection": "Best hidden-head transition F1 among nonzero radii improving its own raw F1 and passing the Macro-F1 constraint. Ties use less smoothing.",
            "smoothing_scores": "SVM uses decision margins. Random forest uses class probabilities.",
        }, indent=2), encoding="utf-8")
    print(f"Selected on validation: {selected}", flush=True)
    test, per_user = evaluate(models, controls + ([selected] if selected else []), test_users, "test")
    if not args.smoke:
        assert (test["test_points"] == 860_972).all() and (test["true_events"] == 658).all()
        prior = test.query("classifier == 'linear_original' and tolerance_s == 60").iloc[0]
        assert prior.matched_events == 333 and prior.predicted_events == 18_224
        test.to_csv(OUT / "test.csv", index=False)
        per_user.to_csv(OUT / "test_per_user.csv", index=False)
    print(test.query("tolerance_s == @PRIMARY").to_string(index=False))


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()

