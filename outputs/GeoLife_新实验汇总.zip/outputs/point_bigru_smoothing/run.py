"""Select two offline post-processors on validation users, then evaluate fixed settings."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch

OUT = Path(__file__).resolve().parent
PILOT = OUT.parent / "point_bigru"
sys.path.insert(0, str(PILOT))
from train import PointTagger, DEVICE, batches, load_blocks, standardize, tensor_batch
from score import TOLERANCES, score_row
from run import match_events

AVERAGE = "score_mean"
CLEANUP = "short_aba"
RAW = ("raw", 0)
PARAMETERS = {AVERAGE: (5, 10, 20, 30, 60, 120), CLEANUP: (3, 5, 10, 20, 30, 60)}
PRIMARY_TOLERANCE = 60
MAX_CLASSIFICATION_DROP = 0.01


def score_average(probabilities, time, radius):
    left = np.searchsorted(time, time - radius, side="left")
    right = np.searchsorted(time, time + radius, side="right")
    sums = np.concatenate((np.zeros((1, probabilities.shape[1])),
                           np.cumsum(probabilities, axis=0, dtype=np.float64)))
    # All class columns share the same positive denominator. Argmax of the sum is sufficient.
    return (sums[right] - sums[left]).argmax(axis=1)


def remove_short_excursions(raw, time, limit):
    starts = np.r_[0, np.flatnonzero(raw[1:] != raw[:-1]) + 1]
    ends = np.r_[starts[1:], len(raw)]
    duration = np.r_[np.diff(time[starts]), time[-1] - time[starts[-1]]]
    labels = raw[starts]
    clean = raw.copy()
    targets = np.flatnonzero((labels[:-2] == labels[2:]) &
                             (duration[1:-1] <= limit) &
                             (duration[:-2] > limit) & (duration[2:] > limit)) + 1
    for i in targets:
        clean[starts[i]:ends[i]] = labels[i - 1]
    return clean


def changes(labels, time):
    return time[np.flatnonzero(labels[1:] != labels[:-1]) + 1]


@torch.inference_mode()
def user_predictions(model, user, mean, std):
    blocks = standardize(load_blocks([user]), mean, std)
    scores = [None] * len(blocks)
    raw = [None] * len(blocks)
    for group in batches(blocks):
        x, _, lengths = tensor_batch(blocks, group)
        logits = model(x, lengths)
        probs = logits.softmax(-1).cpu().numpy()
        labels = logits.argmax(-1).cpu().numpy().astype(np.uint8)
        for row, index in enumerate(group):
            size = len(blocks[index][1])
            scores[index] = probs[row, :size].copy()
            raw[index] = labels[row, :size].copy()
    with np.load(PILOT / "cache" / f"{user}.npz") as saved:
        truth, time, lengths = saved["y"], saved["t"], saved["lengths"]
    edges = np.r_[0, lengths.cumsum()]
    assert np.array_equal(np.concatenate([y.numpy() for _, y in blocks]), truth)
    return [(truth[a:b], time[a:b], labels, probs)
            for a, b, labels, probs in zip(edges[:-1], edges[1:], raw, scores)]


def evaluate(model, users, settings, mean, std, split):
    matrices = {setting: np.zeros((5, 5), dtype=np.int64) for setting in settings}
    counts = {setting: np.zeros(2 + len(TOLERANCES), dtype=np.int64) for setting in settings}
    by_user = []
    for user in users:
        blocks = user_predictions(model, user, mean, std)
        if split == "test":
            with np.load(PILOT / "predictions" / f"{user}.npz") as prior:
                np.testing.assert_array_equal(np.concatenate([block[2] for block in blocks]),
                                              prior["pred"], err_msg=f"{user}: original checkpoint")
        local_cm = {setting: np.zeros((5, 5), dtype=np.int64) for setting in settings}
        local_counts = {setting: np.zeros(2 + len(TOLERANCES), dtype=np.int64) for setting in settings}
        for truth, time, raw, probabilities in blocks:
            assert np.all(np.diff(time) > 0)
            actual = changes(truth, time)
            truth_code = truth.astype(np.int64) * 5
            for setting in settings:
                name, seconds = setting
                prediction = raw
                if name == AVERAGE:
                    prediction = score_average(probabilities, time, seconds)
                elif name == CLEANUP:
                    prediction = remove_short_excursions(raw, time, seconds)
                proposed = changes(prediction, time)
                local_cm[setting] += np.bincount(truth_code + prediction, minlength=25).reshape(5, 5)
                local_counts[setting] += (len(actual), len(proposed),
                                          *(match_events(actual, proposed, tol) for tol in TOLERANCES))
        for setting in settings:
            matrices[setting] += local_cm[setting]
            counts[setting] += local_counts[setting]
            for tol, hits in zip(TOLERANCES, local_counts[setting][2:]):
                by_user.append(metric_row(setting, tol, local_cm[setting], *local_counts[setting][:2], hits,
                                          user_id=user))
        print(f"{split}: {user}, {sum(len(y) for y, *_ in blocks):,} points", flush=True)
    rows = [metric_row(setting, tol, matrices[setting], *counts[setting][:2], hits)
            for setting in settings for tol, hits in zip(TOLERANCES, counts[setting][2:])]
    return pd.DataFrame(rows), pd.DataFrame(by_user)


def metric_row(setting, tolerance, matrix, actual, predicted, hits, **fields):
    return dict(method=setting[0], seconds=setting[1], tolerance_s=tolerance, **fields,
                **score_row(matrix, actual, predicted, hits))


def select_settings(validation):
    primary = validation.loc[validation["tolerance_s"].eq(PRIMARY_TOLERANCE)]
    original = primary.loc[primary["method"].eq("raw")].iloc[0]
    minimum_f1 = original["macro_f1"] - MAX_CLASSIFICATION_DROP
    better = primary.loc[(primary["macro_f1"] >= minimum_f1) &
                         (primary["transition_f1"] > original["transition_f1"])]
    selected = [RAW]
    for method in PARAMETERS:
        candidates = better.loc[better["method"].eq(method)].sort_values(
            ["transition_f1", "seconds"], ascending=[False, True])
        if not candidates.empty:
            selected.append((method, int(candidates.iloc[0]["seconds"])))
    return selected


def smoke_check():
    time = np.array([0, 2, 4, 6, 7, 8, 20, 22])
    raw = np.array([0, 0, 0, 1, 1, 0, 0, 0])
    np.testing.assert_array_equal(remove_short_excursions(raw, time, 2), np.zeros_like(raw))
    np.testing.assert_array_equal(remove_short_excursions(raw, time, 1), raw)
    np.testing.assert_array_equal(remove_short_excursions(np.array([0]),
                                                          np.array([0]), 8), [0])
    probs = np.array([[0.9, 0.1], [0.2, 0.8], [0.9, 0.1]])
    np.testing.assert_array_equal(score_average(probs, np.array([0, 6, 7]), 1), [0, 0, 0])
    np.testing.assert_array_equal(score_average(probs, np.array([0, 6, 7]), 0), [0, 1, 0])


def main():
    smoke_check()
    meta = json.loads((PILOT / "training.json").read_text(encoding="utf-8"))
    assert not set(meta["val_users"]) & set(meta["test_users"])
    assert not set(meta["fit_users"]) & set(meta["val_users"])
    torch.set_num_threads(3)
    model = PointTagger().to(DEVICE)
    model.load_state_dict(torch.load(PILOT / "bigru.pt", map_location=DEVICE, weights_only=True))
    model.eval()
    mean, std = (np.asarray(meta[k], dtype=np.float32) for k in ("mean", "std"))
    settings = [RAW, *((method, s) for method, options in PARAMETERS.items() for s in options)]
    validation, _ = evaluate(model, meta["val_users"], settings, mean, std, "validation")
    validation.to_csv(OUT / "validation.csv", index=False)
    selected = select_settings(validation)
    (OUT / "selection.json").write_text(json.dumps({
        "validation_users": meta["val_users"], "tolerance_s": PRIMARY_TOLERANCE,
        "max_validation_macro_f1_drop": MAX_CLASSIFICATION_DROP,
        "criterion": "Per family, maximize validation transition F1 above raw; ties use fewer seconds.",
        "selected": selected,
    }, indent=2), encoding="utf-8")
    print(f"Chosen on validation: {selected}", flush=True)
    test, per_user = evaluate(model, meta["test_users"], selected, mean, std, "test")
    assert (test["test_points"] == 860_972).all() and (test["true_events"] == 658).all()
    test.to_csv(OUT / "test.csv", index=False)
    per_user.to_csv(OUT / "test_per_user.csv", index=False)
    print(test.loc[test["tolerance_s"].eq(PRIMARY_TOLERANCE)].to_string(index=False))


if __name__ == "__main__":
    main()


