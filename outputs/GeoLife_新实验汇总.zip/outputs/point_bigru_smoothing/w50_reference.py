"""Score the saved W=50 predictions on the same original GPS-point timeline."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(OUT.parent / "point_window_comparison"))
from run import MODELS, MODEL_NAME, MODES, TOLERANCES, event_counts, load_user, metrics_from_cm, predict_windows

head = MODELS / "results/basic_w50_no_dt_v2/window_predictions_test.csv"
windows = pd.read_csv(head, dtype={"user_id": str}, parse_dates=["start_time", "end_time"])
names = {"W50_raw": f"{MODEL_NAME} | raw", "W50_k11": MODEL_NAME}
matrices = {name: np.zeros((5, 5), dtype=np.int64) for name in names}
totals = {name: {tol: np.zeros(3, dtype=np.int64) for tol in TOLERANCES} for name in names}
for uid, saved in windows.groupby("user_id"):
    points = load_user(uid)
    truth = pd.Categorical(points["mode"], categories=MODES).codes.astype(np.int64)
    time = points["timestamp"].to_numpy(dtype="datetime64[s]").astype(np.int64)
    for name, column in names.items():
        group = saved.reset_index(drop=True).copy()
        group[f"{MODEL_NAME} | raw"] = group[column]
        labels, _ = predict_windows(points, 50, saved=group)
        pred = pd.Categorical(labels, categories=MODES).codes.astype(np.int64)
        assert min(pred) >= 0
        matrices[name] += np.bincount(truth * 5 + pred, minlength=25).reshape(5, 5)
        for tol, (actual, proposed, hits, _) in event_counts(points, pred, time).items():
            totals[name][tol] += (actual, proposed, hits)
rows = []
for name in names:
    n = matrices[name].sum()
    assert n == 860_972
    for tol, (actual, proposed, hits) in totals[name].items():
        assert actual == 658
        rows.append(dict(method=name, tolerance_s=tol, test_points=n,
                         macro_f1=metrics_from_cm(matrices[name])["macro_f1"],
                         true_events=actual, predicted_events=proposed, matched_events=hits,
                         transition_precision=hits / proposed, transition_recall=hits / actual,
                         transition_f1=2 * hits / (proposed + actual)))
table = pd.DataFrame(rows)
prior = pd.read_csv(OUT.parent / "point_bigru/results.csv").query("configuration == 'W50'")
np.testing.assert_allclose(table.query("method == 'W50_raw'")["transition_f1"], prior["transition_f1"])
table.to_csv(OUT / "w50_reference.csv", index=False)
print(table.to_string(index=False))
