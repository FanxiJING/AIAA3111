"""Compare unsmoothed Part 2 predictions at three resolutions on identical GPS points."""

from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
MODELS = ROOT / "src" / "model_training"
sys.path.insert(0, str(MODELS))

from build_windows import (DEFAULT_POINTS, DEFAULT_SPLITS, assign_windows, load_split,
                           read_points, window_features)
from models import MODES, load_windows, metrics_from_cm, prepare
from pipeline_v2 import SEED, SPLITS_REPORT, SVM_NAMES, model_specs

POINT_FEATURES = [
    "distance_m", "speed_mps", "acceleration_mps2", "jerk_mps3",
    "heading_change_rad", "heading_change_rate_rad_s",
]
POINT_SAMPLE = 70_000
TOLERANCES = (30, 60, 120)
BATCH_SIZE = 10_000
MODEL_NAME = SVM_NAMES[1]


def load_user(uid):
    points = read_points(DEFAULT_POINTS / f"{uid}.parquet")
    return (points.loc[points["mode"].isin(MODES)]
            .sort_values(["feature_block_id", "timestamp"], kind="stable")
            .reset_index(drop=True))


def fit_svm(features, labels):
    model = model_specs(features.shape[1])[MODEL_NAME].make(True)
    return model.set_params(clf__C=1.0, verbose=True).fit(features, labels)


def point_features(points):
    return points[POINT_FEATURES].replace([np.inf, -np.inf], np.nan)


def fit_point_model(train_users):
    train = pd.concat([
        load_user(uid)[["mode", *POINT_FEATURES]] for uid in train_users
    ], ignore_index=True)
    sample, _ = train_test_split(
        np.arange(len(train)), train_size=POINT_SAMPLE,
        stratify=train["mode"], random_state=SEED,
    )
    sample = train.iloc[np.sort(sample)]
    print(f"Point model: {len(sample):,} training points", flush=True)
    return fit_svm(point_features(sample), sample["mode"])


def fit_window_model(train_users, size):
    tables = []
    for uid in train_users:
        points = load_user(uid)
        points["window_id"] = assign_windows(points, size, cut_at_label_change=True)
        tables.append(window_features(points))
    windows = pd.concat(tables, ignore_index=True)
    X, y, _, _ = prepare(windows.loc[windows["n_points"] >= 10])
    print(f"W={size}: {len(y):,} training windows", flush=True)
    return fit_svm(X, y), len(y)


def match_events(truth, predicted, tolerance):
    """Maximum cardinality one-to-one matching of sorted event times within a block."""
    i = j = matched = 0
    while i < len(truth) and j < len(predicted):
        difference = predicted[j] - truth[i]
        if difference < -tolerance:
            j += 1
        elif difference > tolerance:
            i += 1
        else:
            matched += 1
            i += 1
            j += 1
    return matched


def event_counts(points, predicted, available_s):
    timestamps = points["timestamp"].to_numpy(dtype="datetime64[s]").astype(np.int64)
    true = points["mode"].to_numpy()
    blocks = points["feature_block_id"].to_numpy()
    boundaries = np.r_[0, np.flatnonzero(blocks[1:] != blocks[:-1]) + 1, len(points)]
    totals = {tol: np.zeros(4, dtype=np.int64) for tol in TOLERANCES}
    for start, end in zip(boundaries[:-1], boundaries[1:]):
        actual = np.flatnonzero(true[start + 1:end] != true[start:end - 1]) + start + 1
        changes = (np.flatnonzero(predicted[start + 1:end] != predicted[start:end - 1])
                   + start + 1)
        if not len(actual) and not len(changes):
            continue
        for tol in TOLERANCES:
            totals[tol] += (
                len(actual), len(changes),
                match_events(timestamps[actual], timestamps[changes], tol),
                match_events(timestamps[actual], available_s[changes], tol),
            )
    return totals


def predict_windows(points, size, model=None, saved=None):
    points["window_id"] = assign_windows(points, size, cut_at_label_change=False)
    keys = ["feature_block_id", "start_time", "end_time", "n_points"]
    if saved is not None:
        windows = (points.groupby("window_id", sort=True)
                   .agg(feature_block_id=("feature_block_id", "first"),
                        start_time=("timestamp", "min"), end_time=("timestamp", "max"),
                        n_points=("timestamp", "size")).reset_index(drop=True))
        pd.testing.assert_frame_equal(windows[keys], saved[keys], check_dtype=False)
        labels = saved[f"{MODEL_NAME} | raw"].to_numpy()
    else:
        windows = window_features(points)
        labels = model.predict(prepare(windows)[0])
    ids = points["window_id"].to_numpy()
    end_s = windows["end_time"].to_numpy(dtype="datetime64[s]").astype(np.int64)
    return labels[ids], end_s[ids]


def main():
    assert match_events(np.array([10]), np.array([8, 9]), 3) == 1
    assert match_events(np.array([10, 12]), np.array([8, 10]), 2) == 2
    assert match_events(np.array([10]), np.array([13]), 2) == 0

    split = load_split(DEFAULT_SPLITS)
    train = sorted(uid for uid, group in split.items() if group == "train")
    test = sorted(uid for uid, group in split.items() if group == "test")
    print(f"{len(train)} train users, {len(test)} test users", flush=True)
    v2 = MODELS / "results" / "basic_w50_no_dt_v2"
    saved = pd.read_csv(v2 / "window_predictions_test.csv", dtype={"user_id": str},
                        parse_dates=["start_time", "end_time"])
    original = load_windows(MODELS / "windows_w50.csv")
    sizes = {"point": POINT_SAMPLE, "W25": 0,
             "W50": int(((original["split"] == "train") & (original["n_points"] >= 10)).sum())}
    del original

    print("Fitting point model", flush=True)
    point_model = fit_point_model(train)
    print("Fitting W=25 model", flush=True)
    w25_model, sizes["W25"] = fit_window_model(train, 25)

    names = ("point", "W25", "W50")
    matrices = {name: np.zeros((len(MODES), len(MODES)), dtype=np.int64) for name in names}
    totals = {name: {tol: np.zeros(4, dtype=np.int64) for tol in TOLERANCES} for name in names}
    per_user = []
    for uid in test:
        points = load_user(uid)
        X = point_features(points)
        point_pred = np.concatenate([
            point_model.predict(X.iloc[start:start + BATCH_SIZE])
            for start in range(0, len(X), BATCH_SIZE)
        ])
        point_time = points["timestamp"].to_numpy(dtype="datetime64[s]").astype(np.int64)
        w25 = predict_windows(points, 25, model=w25_model)
        w50 = predict_windows(points, 50, saved=saved.loc[saved["user_id"] == uid].reset_index(drop=True))
        for name, (pred, available) in zip(names, ((point_pred, point_time), w25, w50)):
            matrix = confusion_matrix(points["mode"], pred, labels=MODES)
            assert matrix.sum() == len(points)
            matrices[name] += matrix
            counts = event_counts(points, pred, available)
            for tol, values in counts.items():
                totals[name][tol] += values
                per_user.append({"configuration": name, "user_id": uid, "tolerance_s": tol,
                                 "test_points": len(points), "macro_f1": metrics_from_cm(matrix)["macro_f1"],
                                 **dict(zip(("true_events", "predicted_events", "matched_at_start",
                                             "matched_at_output"), values))})
        print(f"{uid}: {len(points):,} test points scored", flush=True)

    rows = []
    assert matrices["W50"].sum() == 860_972
    assert abs(metrics_from_cm(matrices["W50"])["macro_f1"] - 0.7789104085733742) < 1e-10
    for name in names:
        metrics = metrics_from_cm(matrices[name])
        for tol, (true, pred, start_hits, output_hits) in totals[name].items():
            assert true == totals["W50"][tol][0]
            for timing, hits in (("window_start", start_hits), ("output_time", output_hits)):
                rows.append({
                    "configuration": name, "train_rows": sizes[name],
                    "test_points": matrices[name].sum(), "macro_f1": metrics["macro_f1"], "accuracy": metrics["accuracy"],
                    "tolerance_s": tol, "timing": timing, "true_events": true,
                    "predicted_events": pred, "matched_events": hits,
                    "transition_precision": hits / pred, "transition_recall": hits / true,
                    "transition_f1": 2 * hits / (true + pred),
                })
    summary = pd.DataFrame(rows)
    summary.to_csv(OUT / "results.csv", index=False)
    pd.DataFrame(per_user).to_csv(OUT / "per_user.csv", index=False)
    print(summary.to_string(index=False), flush=True)


if __name__ == "__main__":
    main()


