"""Score saved robust_g3 predictions using the GeoLife offline transition protocol."""
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score

from evaluate import KEYS, MODES, OUT, ROOT

sys.path.insert(0, str(OUT.parent / "point_window_comparison"))
from run import event_counts, MODEL_NAME, predict_windows

TOLERANCE = 60


def main():
    summary = json.loads((OUT / "metrics.json").read_text(encoding="utf-8"))
    points = pd.concat([
        pd.read_parquet(
            ROOT / f"data/processed/quality_features/{user}.parquet", columns=[*KEYS, "mode"],
        )
        for user in summary["users"]
    ], ignore_index=True)
    predictions = pd.read_parquet(OUT / "test_predictions.parquet")
    pd.testing.assert_frame_equal(points[KEYS], predictions[KEYS])
    points["predicted_mode"] = predictions["predicted_mode"]
    assert points["predicted_mode"].isin(MODES).all()
    accuracy = accuracy_score(points["mode"], points["predicted_mode"])
    macro_f1 = f1_score(points["mode"], points["predicted_mode"], labels=MODES, average="macro")
    np.testing.assert_allclose(
        [accuracy, macro_f1], [summary["point_accuracy"], summary["point_macro_f1"]],
    )

    baseline = pd.read_csv(
        ROOT / "src/model_training/results/basic_w50_no_dt_v2/window_predictions_test.csv",
        dtype={"user_id": str}, parse_dates=["start_time", "end_time"],
    )
    totals = np.zeros(3, dtype=np.int64)
    reference = np.zeros(3, dtype=np.int64)
    for user, track in points.groupby("user_id", sort=False):
        track = track.sort_values(["feature_block_id", "timestamp"], kind="stable").copy()
        timestamps = track["timestamp"].to_numpy(dtype="datetime64[s]").astype(np.int64)
        totals += event_counts(track, track["predicted_mode"].to_numpy(), timestamps)[TOLERANCE][:3]
        saved = baseline.loc[baseline["user_id"].eq(user)].reset_index(drop=True)
        labels, _ = predict_windows(track, 50, saved=saved)
        reference += event_counts(track, labels, timestamps)[TOLERANCE][:3]

    # Reproduce the screenshot's unsmoothed W50 reference with the same scorer.
    np.testing.assert_array_equal(reference, [658, 3014, 289])
    actual, proposed, hits = totals
    assert actual == reference[0]
    assert len(points) == summary["scored_points"] == 860_972
    row = {
        "方案": "robust_g3（50 点窗 HGB）",
        "点级准确率": f"{accuracy:.2%}",
        "点级 Macro-F1": f"{macro_f1:.4f}",
        "命中 / 预测切换数": f"{hits:,} / {proposed:,}",
        "切换准确率": f"{hits / proposed:.2%}" if proposed else "0.00%",
        "切换召回率": f"{hits / actual:.2%}",
        "切换 F1": f"{2 * hits / (actual + proposed):.4f}",
    }
    pd.DataFrame([row]).to_csv(OUT / "comparison_row.csv", index=False, encoding="utf-8-sig")
    print(json.dumps(row, ensure_ascii=True))
    print(f"Verified W50 reference={reference.tolist()}, robust_g3 counts={totals.tolist()}")


if __name__ == "__main__":
    main()
