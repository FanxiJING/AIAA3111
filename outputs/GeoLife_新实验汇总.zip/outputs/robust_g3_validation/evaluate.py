"""Evaluate the supplied prediction CLI on the fixed GeoLife test split."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

import numpy as np
import pandas as pd
from sklearn.metrics import classification_report, confusion_matrix, f1_score

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
KEYS = ["user_id", "feature_block_id", "timestamp", "latitude", "longitude"]
MODES = ["walk", "bike", "bus", "car", "train"]


def main():
    model = Path(sys.argv[1]).resolve()
    users = json.loads((ROOT / "data/splits/test_users.json").read_text())
    inputs = []
    for user in users:
        points = pd.read_parquet(
            ROOT / f"data/processed/quality_features/{user}.parquet",
            columns=[*KEYS, "point_id", "mode"],
        )
        if points.empty or not points["user_id"].eq(user).all():
            raise ValueError(f"Unexpected test data for user {user}")
        inputs.append(points)
    truth = pd.concat(inputs, ignore_index=True)
    if not truth["mode"].isin(MODES).all():
        raise ValueError("Unexpected or missing test labels")

    test_input = OUT / "test_input.parquet"
    prediction_file = OUT / "test_predictions.parquet"
    truth[KEYS].to_parquet(test_input, index=False)
    started = time.perf_counter()
    subprocess.run([
        sys.executable, "-B", str(OUT / "predict.py"), str(test_input),
        str(prediction_file), "--model", str(model),
    ], check=True)
    elapsed = time.perf_counter() - started

    predicted = pd.read_parquet(prediction_file)
    pd.testing.assert_frame_equal(predicted[KEYS], truth[KEYS])
    labels = predicted["predicted_mode"]
    if not labels.isin(MODES).all():
        raise ValueError("Unexpected or missing predicted classes")
    matrix = confusion_matrix(truth["mode"], labels, labels=MODES)
    assert int(matrix.sum()) == len(truth)
    report = classification_report(
        truth["mode"], labels, labels=MODES, output_dict=True, zero_division=0,
    )
    pd.DataFrame([report[mode] for mode in MODES], index=MODES).rename_axis(
        "mode"
    ).to_csv(OUT / "per_class.csv")
    pd.DataFrame(matrix, index=MODES, columns=MODES).rename_axis(
        "true_mode"
    ).to_csv(OUT / "confusion_matrix.csv")
    per_user = []
    for user, group in truth.groupby("user_id", sort=False):
        actual, predicted_user = group["mode"], labels.loc[group.index]
        present = [mode for mode in MODES if actual.eq(mode).any()]
        per_user.append({
            "user_id": user, "points": len(group),
            "accuracy": float(actual.eq(predicted_user).mean()),
            "macro_f1_true_classes": f1_score(
                actual, predicted_user, labels=present, average="macro", zero_division=0,
            ),
        })
    pd.DataFrame(per_user).to_csv(OUT / "per_user.csv", index=False)
    summary = {
        "model_sha256": hashlib.sha256(model.read_bytes()).hexdigest(),
        "users": users, "points": len(truth), "scored_points": int(matrix.sum()),
        "point_macro_f1": report["macro avg"]["f1-score"],
        "point_accuracy": report["accuracy"],
        "inference_cli_seconds": elapsed,
    }
    (OUT / "metrics.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
