# GeoLife 与外测指标数据

## 模型

| CSV 名称 | 含义 |
|---|---|
| `original_g3` | 交付包里的原始 G3，27 个特征，Nyström SVM，逐窗预测 |
| `original_g3_offline` | 同一权重，居中 11 窗软投票。原始 GPS 预测与 Part 2 v2 最终结果逐窗吻合 |
| `offline_robust_g3` | 交付包正式入口的冻结权重，65 个多尺度特征，HGB，使用块内前后各最多 4 窗的时间加权概率 |

## 数据文件

| 文件 | 内容 |
|---|---|
| `geolife_summary.csv` | 原始坐标、5/10/20 m 独立抖动和连续漂移的点级 Macro-F1、准确率、火车点占比 |
| `geolife_by_seed.csv` | 每个噪声实现和模型的点级整体结果 |
| `geolife_classes_by_seed.csv` | 各条件、种子、模型的五类精确率、召回率、F1、点数与错判去向 |
| `geolife_clean_by_class.csv` | 原始坐标的逐类指标和三张混淆矩阵 |
| `geolife_clean_correct_counts.csv` | 截图中的逐类判对点数，附离线鲁棒 G3 相对两个旧对照的净变化 |
| `geolife_clean_transitions.csv` | 原始坐标的切换点精确率、召回率、F1、真实切换数、预测切换数和命中数，提供 ±30、±60、±120 秒三档容差 |
| `external_summary.csv` | Urban Routes、Zenodo 与 Go!Track 的整体点级和逐轨迹指标 |
| `external_classes.csv` | 外测逐类指标和错判去向 |
| `external_by_recording.csv` | 每条外测原始轨迹的类别、点数和三个模型的准确率 |
| `context_selection.csv` / `context_selection_folds.csv` | 选型的九种候选配置与逐折得分 |
| `timing_summary.csv` / `timing_by_run.csv` | 单线程批量预测中位耗时、各次耗时、特征数与权重文件大小 |

GeoLife 使用同一批 13 位测试用户的 860,972 个点和 17,380 个窗口。原始组跑一次。每个扰动档位使用相同的五个种子（20261123–20261127）。噪声强度是东西、南北方向各自的标准差，连续漂移的相关时间尺度为 30 秒。Macro-F1 对五类等权。测试集已多次用于历史复测。

逐类表按真值类别排每一行，`pred_walk` 到 `pred_train` 是预测类别计数。`true_points` 是该行合计，`predicted_points` 是该预测类别的列合计。精确率和召回率分别用判对点数除以预测点数和真实点数。CSV 中比例为 0 到 1。

切换点按连续轨迹块内相邻点的类别变化定位，取新类别首点的时间。预测与真值按时间在同一块内一对一匹配。精确率为命中数除以预测切换数，召回率为命中数除以 658 个真实切换点。离线回放使用预测切换点对应的 GPS 时间。

外测来自交付包 `experiments/robust_g3/urban_results/` 的存档，宏平均只纳入该来源有真值的类别。Go!Track 有 163 条原始轨迹和 165 个清洗后片段，共评分 18,105 点。逐轨迹平均准确率以 163 条原始轨迹为单位。各来源无真实样本的类别召回率留空。

选型记录来自交付包 `experiments/robust_g3/context_results/`。综合分先对训练用户五折、原始 GPS 和两类 20 m 扰动等权平均，再用 75% 的五类 Macro-F1 和 25% 的公交、汽车平均 F1 加权。入选配置为半径 4、公交系数 1.0，综合分 0.567119。

测速在本机 Intel Core i7-13700H 上，用相同 17,380 个窗口和预先生成的两套特征。各模型单线程预热后计时五次，旧平滑版及鲁棒版包含各自的离线解码。单位为毫秒，计时范围从模型读取内存特征开始，到输出窗口预测结束。离线场景还需要等后续 GPS 观测可用。
