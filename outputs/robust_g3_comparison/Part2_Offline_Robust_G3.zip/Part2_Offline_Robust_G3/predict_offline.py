"""Predict one travel mode per GPS point with the frozen offline G3."""
import argparse
from functools import lru_cache
from pathlib import Path
import sys

import joblib
import pandas as pd
from threadpoolctl import threadpool_limits

EXPERIMENT = Path(__file__).resolve().parent / "experiments" / "robust_g3"
sys.path.insert(0, str(EXPERIMENT))
from features import predict_points


@lru_cache(maxsize=1)
def _model():
    return joblib.load(EXPERIMENT / "context_g3.joblib")


def predict_offline(points):
    """Accept a pre-blocked point DataFrame and return rows in input order."""
    with threadpool_limits(limits=4):
        return predict_points(points, _model())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("points", type=Path, help="Input CSV or Parquet")
    parser.add_argument("output", type=Path, help="New output CSV or Parquet")
    args = parser.parse_args()
    for path in (args.points, args.output):
        if path.suffix.lower() not in {".csv", ".parquet"}:
            parser.error(f"Expected .csv or .parquet: {path}")
    if args.output.exists():
        parser.error(f"Output already exists: {args.output}")
    if args.points.suffix.lower() == ".parquet":
        points = pd.read_parquet(args.points)
    else:
        points = pd.read_csv(args.points, dtype={"user_id": str, "feature_block_id": str})
    predictions = predict_offline(points)
    if args.output.suffix.lower() == ".parquet":
        predictions.to_parquet(args.output, index=False)
    else:
        predictions.to_csv(args.output, index=False)


if __name__ == "__main__":
    main()
