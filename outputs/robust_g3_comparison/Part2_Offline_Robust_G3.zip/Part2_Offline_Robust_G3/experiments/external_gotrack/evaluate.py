"""Paired, frozen-model evaluation on the UCI Go!Track release."""
import argparse
import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
from threadpoolctl import threadpool_limits

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ROBUST = HERE.parent / "robust_g3"
sys.path[:0] = [str(ROOT / "src"), str(ROBUST)]
from data_preprocessing.clean_trips import clean_user
from features import predict_points
from feature_enginneering.motion_features import build_features
from feature_enginneering.quality_features import repair_connections
from build_windows import MODES, assign_windows, window_features

CLASSES = ["bus", "car"]
INPUT_HASHES = {
    "go_track_tracks.csv": "cabbef5443854b73239fbf590b49a05cd50135ea6504233db7a796dc5ee910d7",
    "go_track_trackspoints.csv": "1130fc4a5f4a7bac236e60ca1826ded274ecba63eee5c340acfe6a2f825175a2",
    "full.joblib": "328692f6ae7201144216fddd2f032812c405438f1338f6c1ac416fe149d57866",
    "robust_g3.joblib": "e8db30537cd38f1c309a5366ff4f47941f774bf8a24c99bc87405ee069c1c8ce",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(raw):
    cleaned, audit = [], Counter()
    for track, rows in raw.groupby("track_id", sort=True):
        # The existing cleaner requires a matched mode; use a constant dummy
        # for every row. Track identity groups points and is never a feature.
        adapted = rows.assign(user_id=f"track_{track}", source_file=str(track),
                              mode="walk", label_status="matched", altitude_ft=np.nan)
        points, counts = clean_user(adapted)
        audit.update(counts)
        if points.empty:
            raise ValueError(f"No valid points for source track {track}")
        points["feature_block_id"] = points.trip_id
        points["feature_block_start"] = points.trip_start
        points = repair_connections(build_features(points))
        audit["speed_breaks"] += int(points.speed_outlier_candidate.sum())
        cleaned.append(points)
    return pd.concat(cleaned, ignore_index=True), dict(audit)


def predict(points, legacy, columns, robust):
    points = points.sort_values(["user_id", "feature_block_id", "timestamp"]).reset_index(drop=True)
    points["window_id"] = assign_windows(points, 50, False)
    windows = window_features(points)
    if len(columns) != 27 or columns != list(legacy.feature_names_in_):
        raise ValueError("Legacy feature schema mismatch")
    old = legacy.predict(windows[columns].replace([np.inf, -np.inf], np.nan))
    out = points[["point_id", "track_id", "window_id"]].copy()
    counts = np.bincount(out.window_id)
    np.testing.assert_array_equal(counts, windows.n_points)
    assert windows.n_points.sum() == len(points)
    out["legacy"] = old[out.window_id.to_numpy()]
    coords = points[["user_id", "feature_block_id", "timestamp", "latitude", "longitude"]]
    out["robust"] = predict_points(coords, robust).predicted_mode.to_numpy()
    assert out.groupby("window_id")[["track_id", "robust"]].nunique().eq(1).all().all()
    for _, track in points.groupby("user_id"):
        # The robust prediction API computes local IDs independently per user.
        np.testing.assert_array_equal(assign_windows(track, 50, False),
                                      track.window_id - track.window_id.min())
    return out


def metrics(points, predicted):
    pred = points[predicted]
    assert pred.isin(MODES).all()
    precision, recall, f1, support = precision_recall_fscore_support(
        points.truth, pred, labels=CLASSES, zero_division=0)
    matrix = pd.crosstab(points.truth, pred).reindex(index=CLASSES, columns=MODES, fill_value=0)
    assert matrix.to_numpy().sum() == len(points)
    return {
        "macro_f1": float(f1.mean()), "accuracy": accuracy_score(points.truth, pred),
        "mean_trip_accuracy": float(pred.eq(points.truth).groupby(points.track_id).mean().mean()),
        "classes": {c: {"points": int(n), "precision": p, "recall": r, "f1": f}
                    for c, n, p, r, f in zip(CLASSES, support, precision, recall, f1)},
        "confusion_true_by_pred": matrix.to_dict(orient="index"),
    }


def paired_interval(points):
    devices = []
    for _, subset in points.groupby("id_android"):
        cells = []
        for model in ["legacy", "robust"]:
            arr = [[sum(subset.truth.eq(c) & subset[model].eq(c)),
                    sum(subset.truth.eq(c)), sum(subset[model].eq(c))] for c in CLASSES]
            cells.append(arr)
        devices.append(cells)
    cells = np.array(devices)
    ids = np.random.default_rng(20261124).integers(len(devices), size=(5000, len(devices)))
    total = cells[ids].sum(axis=1)
    total = total[total[:, 0, :, 1].min(axis=1) > 0]
    scores = (2 * total[..., 0] / (total[..., 1] + total[..., 2])).mean(axis=2)
    return {"replicates": len(scores), "ci95": np.quantile(scores[:, 1] - scores[:, 0],
                                                          [.025, .975]).tolist()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True)
    parser.add_argument("--legacy", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    paths = [args.data / "go_track_tracks.csv", args.data / "go_track_trackspoints.csv",
             args.legacy / "full.joblib", ROBUST / "robust_g3.joblib"]
    hashes = {p.name: digest(p) for p in paths}
    if hashes != INPUT_HASHES:
        raise ValueError("Input file differs from pinned release/model")
    columns_path = args.legacy / "feature_columns_G3.json"
    hashes[columns_path.name] = digest(columns_path)
    raw = pd.read_csv(paths[1], parse_dates=["time"]).rename(columns={"id": "point_id", "time": "timestamp"})
    assert raw.point_id.is_unique and raw.track_id.notna().all()
    prepared, audit = prepare(raw)
    with threadpool_limits(limits=4):
        predictions = predict(prepared, joblib.load(paths[2]), json.loads(columns_path.read_text()),
                              joblib.load(paths[3]))

    tracks = pd.read_csv(paths[0], usecols=["id", "id_android", "car_or_bus"]).rename(columns={"id": "track_id"})
    tracks["truth"] = tracks.car_or_bus.map({1: "car", 2: "bus"})
    assert tracks.track_id.is_unique and not tracks.isna().any().any()
    assert set(raw.track_id) == set(tracks.track_id) == set(predictions.track_id)
    points = predictions.merge(tracks.drop(columns="car_or_bus"), on="track_id", validate="many_to_one")
    assert len(points) == audit["output_points"] and points.point_id.is_unique
    points["majority"] = points.truth.value_counts().idxmax()
    results = {name: metrics(points, name) for name in ["legacy", "robust", "majority"]}
    report = {"source_doi": "10.24432/C54S5Z", "sha256": hashes, "sklearn": sklearn.__version__,
              "cleaning": audit, "tracks": len(tracks), "devices": int(tracks.id_android.nunique()),
              "tracks_by_class": tracks.truth.value_counts().to_dict(),
              "blocks": int(prepared.feature_block_id.nunique()), "windows": int(points.window_id.nunique()),
              "scores": results, "robust_minus_legacy_macro_f1": results["robust"]["macro_f1"] - results["legacy"]["macro_f1"],
              "paired_device_bootstrap": paired_interval(points)}
    args.out.mkdir(exist_ok=True, parents=True)
    points.drop(columns="majority").to_parquet(args.out / "predictions.parquet", index=False)
    text = json.dumps(report, indent=2, allow_nan=False)
    (args.out / "results.json").write_text(text + "\n", encoding="utf-8")
    print(text)


if __name__ == "__main__":
    main()
