"""Within-window motion features and label-free W50 inference."""
from pathlib import Path
import sys
import warnings

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src/model_training"))
from build_windows import assign_windows


def ordered(points):
    return points.sort_values(["user_id", "feature_block_id", "timestamp"], kind="stable")


def ratio(a, b):
    return np.divide(a, b, out=np.full(np.broadcast_shapes(a.shape, b.shape), np.nan),
                     where=b > 0)


def window_layout(ids):
    starts = np.r_[0, np.flatnonzero(np.diff(ids)) + 1]
    sizes = np.diff(np.r_[starts, len(ids)])
    return starts, sizes


def extract(points, ids):
    starts, sizes = window_layout(ids)
    lat = np.deg2rad(points.latitude.to_numpy(dtype=float))
    lon = np.deg2rad(points.longitude.to_numpy(dtype=float))
    seconds = (points.timestamp - points.timestamp.iloc[0]).dt.total_seconds().to_numpy()
    parts = []
    for offset in range(0, len(starts), 512):
        start, size = starts[offset:offset + 512], sizes[offset:offset + 512]
        col = np.arange(max(32, size.max()))[None, :]
        idx = start[:, None] + np.minimum(col, size[:, None] - 1)
        valid = col < size[:, None]
        # Window-local equirectangular projection; wrap across the dateline.
        dlon = (lon[idx] - lon[start, None] + np.pi) % (2 * np.pi) - np.pi
        x = dlon * np.cos(lat[start, None]) * 6371008.8
        y = (lat[idx] - lat[start, None]) * 6371008.8
        t = seconds[idx] - seconds[start, None]
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)  # all-missing short tails
            parts.append(_batch(x, y, t, size, valid))
    return pd.concat(parts, ignore_index=True).astype("float32")


def _batch(x, y, t, size, valid):
    rows = np.arange(len(size))
    end = size - 1
    duration = t[rows, end]
    direct = np.hypot(x[rows, end], y[rows, end])
    out = {"duration_s": duration, "net_speed": ratio(direct, duration)}

    def describe(prefix, values):
        sorted_values = np.sort(values, axis=1)
        last = np.maximum(np.isfinite(values).sum(axis=1) - 1, 0)
        for name, q in (("p10", .1), ("median", .5), ("p90", .9)):
            out[f"{prefix}_{name}"] = sorted_values[rows, np.rint(last * q).astype(int)]
        out[f"{prefix}_mean"] = np.nanmean(values, axis=1)

    def motion(prefix, dx, dy, dt, mask):
        dist = np.hypot(dx, dy)
        speed = np.where(mask, ratio(dist, dt), np.nan)
        describe(prefix, speed)
        for threshold in (.5, 2.):
            out[f"{prefix}_below_{threshold:g}"] = ratio(
                np.sum(speed < threshold, axis=1), np.isfinite(speed).sum(axis=1))
        return speed

    for lag in (1, 4, 12):
        dx, dy, dt = (a[:, lag:] - a[:, :-lag] for a in (x, y, t))
        speed = motion(f"v{lag}", dx, dy, dt, valid[:, lag:])
        if lag == 1:
            path = np.where(valid[:, 1:], np.hypot(dx, dy), 0).sum(axis=1)
            out.update(path_m=path, straightness=ratio(direct, path),
                       path_speed=ratio(path, duration))
        acc = ratio(np.abs(speed[:, lag:] - speed[:, :-lag]),
                    (dt[:, lag:] + dt[:, :-lag]) / 2)
        describe(f"acc{lag}", acc)
        ax, ay, bx, by = dx[:, :-lag], dy[:, :-lag], dx[:, lag:], dy[:, lag:]
        angles = np.arctan2(np.abs(ax * by - ay * bx), ax * bx + ay * by)
        moving = (np.hypot(ax, ay) > 0) & (np.hypot(bx, by) > 0)
        describe(f"turn{lag}", np.where(valid[:, 2*lag:] & moving, angles, np.nan))

    # First observation at least H seconds later, wholly inside each window.
    # Separate rows in the search domain even when unrelated blocks overlap in time.
    stride = np.max(t) + 64
    keys = t + rows[:, None] * stride
    for horizon in (10, 30):
        pos = np.searchsorted(keys.ravel(), keys + horizon)
        pos = np.minimum(pos - rows[:, None] * t.shape[1], end[:, None])
        rr = rows[:, None]
        dt = t[rr, pos] - t
        motion(f"v{horizon}s", x[rr, pos] - x, y[rr, pos] - y, dt,
               valid & (dt >= horizon))

    # Centroid-to-centroid motion reduces high-frequency position jitter.
    def centered(a):
        return sum(a[:, k:k + a.shape[1] - 4] for k in range(5)) / 5

    cx, cy, ct = map(centered, (x, y, t))
    lag = 8
    dx, dy, dt = (a[:, lag:] - a[:, :-lag] for a in (cx, cy, ct))
    motion("centroid_v", dx, dy, dt, valid[:, lag + 4:])
    return pd.DataFrame(out)


def predict_points(points, bundle):
    """Return input rows in original order, plus window prediction. No mode required."""
    required = {"user_id", "feature_block_id", "timestamp", "latitude", "longitude"}
    if not required.issubset(points):
        raise ValueError(f"Missing input columns: {sorted(required - set(points))}")
    points = points.reset_index(drop=True).copy()
    points["timestamp"] = pd.to_datetime(points.timestamp, errors="raise")
    if points[list(required)].isna().any().any():
        raise ValueError("Missing coordinate, time, user or block")
    if not (points.latitude.between(-90, 90) & points.longitude.between(-180, 180)).all():
        raise ValueError("Coordinates must be finite WGS84 degrees")
    output = np.empty(len(points), object)
    for _, user in ordered(points).groupby("user_id", sort=False):
        ids = assign_windows(user, 50, False).to_numpy()
        features = extract(user, ids)
        model = bundle["estimator"]
        matrix = features[bundle["columns"]]
        if "context" in bundle:
            from context import contextual_scores, decide
            spans = user.groupby(ids, sort=True).agg(
                user_id=("user_id", "first"), feature_block_id=("feature_block_id", "first"),
                start_time=("timestamp", "first"), end_time=("timestamp", "last"))
            config = bundle["context"]
            scores = contextual_scores(spans, model.predict_proba(matrix), config["radius"])
            pred = decide(scores, model.classes_, config["bus_factor"])
        else:
            pred = model.predict(matrix)
        output[user.index] = pred[ids]
    return points.assign(predicted_mode=output)
