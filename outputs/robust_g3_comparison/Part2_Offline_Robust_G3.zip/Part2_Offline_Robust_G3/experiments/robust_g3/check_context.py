"""Evaluate the frozen context model on historical diagnostics and new GNSS recordings."""
import argparse
from functools import reduce
import hashlib
import json
from operator import xor
from pathlib import Path
import sys
import zipfile

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix
from threadpoolctl import threadpool_limits

from select_context import OUT, score
from context import contextual_scores, decide
from features import predict_points
from prepare_data import HERE, KEYS, MODES, SEEDS, load
from train import aligned

sys.path.insert(0, str(HERE.parent))
from external_gotrack import evaluate as gotrack

SUPPORTED = ["bike", "bus", "car", "walk"]


def geolife(bundle):
    model = bundle["estimator"]
    config = bundle["context"]
    clean = load("test", "blind_clean")
    rows = []
    for noise, sigma, seed in [("clean", 0, 0)] + [
            (n, s, k) for n in ("iid", "ou") for s in (5, 10, 20) for k in SEEDS]:
        key = f"blind_{noise}_{seed}" + (f"_{sigma}m" if sigma in (5, 10) else "")
        frame = clean if not sigma else aligned(clean[KEYS], load("test", key))
        probs = model.predict_proba(frame[bundle["columns"]])
        for name, pred in [
                ("raw", model.classes_[probs.argmax(axis=1)]),
                ("context", decide(contextual_scores(frame, probs, config["radius"]),
                                   model.classes_, config["bus_factor"]))]:
            rows.append(dict(model=name, noise=noise, sigma=sigma, seed=seed, **score(frame, pred)))
    pd.DataFrame(rows).to_csv(OUT / "geolife_replay.csv", index=False)


def coordinate(value, hemisphere, degree_digits):
    sign = -1 if hemisphere in ("S", "W") else 1
    return sign * (int(value[:degree_digits]) + float(value[degree_digits:]) / 60)


def rmc_records(contents):
    for line in contents.decode("ascii").splitlines():
        sentence = line.split("$", 1)[-1]
        if not sentence.split(",", 1)[0].endswith("RMC"):
            continue
        payload, check = sentence.split("*", 1)
        if reduce(xor, payload.encode(), 0) != int(check[:2], 16):
            raise ValueError("Bad RMC checksum")
        fields = payload.split(",")
        if fields[2] == "A":
            if fields[4] not in ("N", "S") or fields[6] not in ("E", "W"):
                raise ValueError("Invalid RMC hemisphere")
            yield (fields[9] + fields[1].partition(".")[0],
                   float("0." + (fields[1].partition(".")[2] or "0")),
                   coordinate(fields[3], fields[4], 2), coordinate(fields[5], fields[6], 3))


def zenodo(archive):
    frames, tracks, hashes = [], [], {}
    with zipfile.ZipFile(archive) as z:
        for member in sorted(z.namelist()):
            mode = member.split("/")[0].lower()
            if mode not in SUPPORTED or not member.lower().endswith(".nmea"):
                continue
            data = z.read(member)
            hashes[member] = hashlib.sha256(data).hexdigest()
            df = pd.DataFrame(rmc_records(data), columns=["clock", "fraction", "latitude", "longitude"])
            df["timestamp"] = (pd.to_datetime(df.clock, format="%d%m%y%H%M%S") +
                               pd.to_timedelta(df.fraction, unit="s"))
            df["track_id"] = len(tracks)
            tracks.append({"track_id": len(tracks), "truth": mode})
            frames.append(df[["track_id", "timestamp", "latitude", "longitude"]])
    assert {t["truth"] for t in tracks} == set(SUPPORTED)
    points = pd.concat(frames, ignore_index=True)
    points["point_id"] = np.arange(len(points))
    return points, pd.DataFrame(tracks), hashes


def external(raw, truth, supported, legacy_path, bundle, compare=None):
    prepared, cleaning = gotrack.prepare(raw)
    old = joblib.load(legacy_path / "full.joblib")
    names = json.loads((legacy_path / "feature_columns_G3.json").read_text())
    previous = joblib.load(HERE / "robust_g3.joblib")
    preds = gotrack.predict(prepared, old, names, previous)
    inputs = prepared[["user_id", "feature_block_id", "timestamp", "latitude", "longitude"]]
    latest = predict_points(inputs, bundle)
    by_id = pd.Series(latest.predicted_mode.to_numpy(), index=prepared.point_id)
    preds["context"] = preds.point_id.map(by_id)
    if compare is not None:
        for model in ["legacy", "robust"]:
            np.testing.assert_array_equal(preds[model], preds.point_id.map(compare[model]))
    preds = preds.merge(truth, on="track_id", validate="many_to_one")
    assert len(preds) == cleaning["output_points"]
    results = {}
    for model in ["legacy", "robust", "context"]:
        cm = confusion_matrix(preds.truth, preds[model], labels=MODES)
        assert cm.sum() == len(preds)
        f1 = 2 * cm.diagonal() / (cm.sum(0) + cm.sum(1)).clip(min=1)
        recalls = cm.diagonal() / cm.sum(1).clip(min=1)
        indices = [MODES.index(c) for c in supported]
        results[model] = {
            "macro_f1": f1[indices].mean(), "accuracy": cm.trace() / cm.sum(),
            "f1": dict(zip(supported, f1[indices])), "recall": dict(zip(supported, recalls[indices])),
            "confusion_rows_and_columns": MODES, "confusion": cm.tolist()}
    by_track = preds.assign(**{m: preds[m].eq(preds.truth) for m in results}).groupby(
        ["track_id", "truth"]).agg(points=("point_id", "size"), **{m: (m, "mean") for m in results})
    return {"cleaning": cleaning, "windows": preds.window_id.nunique(), "models": results}, by_track


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--zenodo", type=Path, required=True)
    parser.add_argument("--gotrack", type=Path, required=True)
    parser.add_argument("--legacy", type=Path, required=True)
    args = parser.parse_args()
    path = HERE / "context_g3.joblib"
    frozen_hash = json.loads((OUT / "selection.json").read_text())["model_sha256"]
    assert gotrack.digest(path) == frozen_hash
    bundle = joblib.load(path)
    raw, tracks, hashes = zenodo(args.zenodo)
    results, per_track = external(raw, tracks, SUPPORTED, args.legacy, bundle)
    results.update(nmea_sha256=hashes, model_sha256=frozen_hash, doi="10.5281/zenodo.14712684")
    (OUT / "zenodo.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    per_track.to_csv(OUT / "zenodo_tracks.csv")
    for name in ["go_track_trackspoints.csv", "go_track_tracks.csv"]:
        assert gotrack.digest(args.gotrack / name) == gotrack.INPUT_HASHES[name]
    raw = pd.read_csv(args.gotrack / "go_track_trackspoints.csv", parse_dates=["time"]).rename(
        columns={"id": "point_id", "time": "timestamp"})
    tracks = pd.read_csv(args.gotrack / "go_track_tracks.csv").rename(columns={"id": "track_id"})
    tracks["truth"] = tracks.car_or_bus.map({1: "car", 2: "bus"})
    reference = pd.read_parquet(HERE.parent / "external_gotrack/results/predictions.parquet").set_index("point_id")
    results, _ = external(raw, tracks[["track_id", "truth"]], gotrack.CLASSES, args.legacy, bundle, reference)
    (OUT / "gotrack_replay.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    geolife(bundle)


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()
