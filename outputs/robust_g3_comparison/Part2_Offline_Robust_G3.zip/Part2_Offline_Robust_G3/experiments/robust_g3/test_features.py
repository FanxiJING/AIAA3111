import unittest

import numpy as np
import pandas as pd

from features import extract
from context import contextual_scores, decide


class WindowTest(unittest.TestCase):
    def test_context_respects_time_user_block_and_row_order(self):
        ts = pd.Timestamp("2020-01-01") + pd.to_timedelta([0, 60, 720, 30, 40], unit="s")
        spans = pd.DataFrame({"user_id": ["a", "a", "a", "b", "a"],
                              "feature_block_id": ["z", "z", "z", "z", "other"],
                              "start_time": ts, "end_time": ts})
        scores = np.array([[1., 0.], [0., 1.], [1., 0.], [1., 0.], [0., 1.]])
        order = np.array([3, 1, 4, 0, 2])
        result = contextual_scores(spans.iloc[order], scores[order], 4)[np.argsort(order)]
        weight = np.exp(-60 / 240)
        np.testing.assert_allclose(result[0], [1 / (1 + weight), weight / (1 + weight)])
        np.testing.assert_allclose(result[1], result[0, ::-1])
        np.testing.assert_array_equal(result[2:], scores[2:])

    def test_bus_adjustment_only_changes_provisional_car(self):
        probs = np.array([[.36, .42, .22], [.3, .29, .41], [.5, .3, .2]])
        labels = ["bus", "car", "bike"]
        np.testing.assert_array_equal(decide(probs, labels, 1), ["car", "bike", "bus"])
        np.testing.assert_array_equal(decide(probs, labels, 1.25), ["bus", "bike", "bus"])

    def test_first_edge_and_short_tails(self):
        points = pd.DataFrame({"latitude": 0., "longitude": np.rad2deg(
            np.array([0., 100., 101., 102.]) / 6371008.8),
            "timestamp": pd.date_range("2020-01-01", periods=4, freq="s")})
        table = extract(points, [0, 1, 1, 2])
        np.testing.assert_allclose(table.path_m, [0., 1., 0.], atol=1e-5)
        self.assertAlmostEqual(table.net_speed[1], 1.)
        self.assertTrue(table["v10s_mean"].isna().all())

    def test_irregular_horizons_and_dateline(self):
        t = np.array([0., 1., 11., 12., 30., 49.])
        x = np.array([0., 7., 20., 40., 60., 100.])
        points = pd.DataFrame({"latitude": 0., "longitude": (
            179.9998 + np.rad2deg(x / 6371008.8) + 180.) % 360. - 180.,
            "timestamp": pd.Timestamp("2020-01-01") + pd.to_timedelta(t, unit="s")})
        padded = pd.concat([points, points], ignore_index=True)
        features = extract(padded, np.repeat([0, 1], len(points)))
        for h in (10, 30):
            pairs = [(i, np.searchsorted(t, ti + h)) for i, ti in enumerate(t) if ti + h <= t[-1]]
            expected = np.mean([(x[j] - x[i]) / (t[j] - t[i]) for i, j in pairs])
            np.testing.assert_allclose(features[f"v{h}s_mean"], expected, rtol=1e-6)


if __name__ == "__main__":
    unittest.main()
