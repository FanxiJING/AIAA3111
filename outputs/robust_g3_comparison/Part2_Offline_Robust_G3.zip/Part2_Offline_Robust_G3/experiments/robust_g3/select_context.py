"""Select offline context using GeoLife training-user held-out predictions."""
import hashlib
import json

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

from context import contextual_scores, decide
from prepare_data import HERE, KEYS, MODES, ROOT, load, users
from train import aligned, fit_model
from models import cv_groups, metrics_from_cm, point_confusion

OUT = HERE / "context_results"
CONFIGS = [(r, b) for r in (0, 2, 4) for b in (1., 1.25, 1.5)]


def score(meta, pred):
    cm = point_confusion(meta, pred, MODES)
    result = metrics_from_cm(cm)
    return {"macro": result["macro_f1"], "accuracy": result["accuracy"],
            **dict(zip(MODES, result["per_class_f1"])),
            "bus_recall": cm[MODES.index("bus"), MODES.index("bus")] /
            max(1, cm[MODES.index("bus")].sum())}


def main():
    OUT.mkdir(exist_ok=True)
    clean = load("train", "fit_clean")
    aug = aligned(clean, load("train", "fit_aug"))
    meta = load("train", "blind_clean")
    frames = {"clean": meta, **{n: aligned(meta, load("train", f"blind_{n}_84221"))
                                for n in ("iid", "ou")}}
    frozen = json.loads((HERE / "selection.json").read_text())
    columns, folds = frozen["columns"], frozen["folds"]
    keep = clean.n_points.ge(10)
    assert set(clean.loc[keep, "user_id"]) == set(folds)
    report = ROOT / "data/splits/report.json"
    assert report.is_file()
    groups = cv_groups(clean.user_id, report)
    assert set(groups).isdisjoint(cv_groups(pd.Series(users("test")), report))
    rows = []
    for fold in range(5):
        fit = keep & clean.user_id.map(folds).ne(fold)
        val = meta.user_id.map(folds).eq(fold)
        assert set(groups[fit]).isdisjoint(cv_groups(meta.loc[val, "user_id"], report))
        print(f"Fitting fold {fold + 1}/5", flush=True)
        estimator = fit_model(clean, aug, columns, fit, augmented=True)
        val_meta = meta.loc[val, KEYS]
        for noise, frame in frames.items():
            probs = estimator.predict_proba(frame.loc[val, columns])
            for radius, factor in CONFIGS:
                pred = decide(contextual_scores(val_meta, probs, radius), estimator.classes_, factor)
                rows.append(dict(fold=fold, noise=noise, radius=radius, bus_factor=factor,
                                 **score(val_meta, pred)))
        print(f"Scored fold {fold + 1}/5", flush=True)
    table = pd.DataFrame(rows)
    table.to_csv(OUT / "training_folds.csv", index=False)
    means = table.groupby(["radius", "bus_factor", "noise"]).mean(numeric_only=True)
    base = means.loc[(0, 1.)].sort_index()
    old_means = frozen["cv_means"]["multiscale_aug"]
    for noise in frames:
        np.testing.assert_allclose(base.loc[noise, "macro"], old_means[noise], atol=1e-6)
    candidates = []
    for radius, factor in CONFIGS:
        m = means.loc[(radius, factor)].sort_index()
        gap = m - base
        eligible = bool((gap.macro >= -.01).all() and (gap.loc["clean", MODES] >= -.03).all())
        road = m.loc[:, ["bus", "car"]].to_numpy().mean()
        utility = .75 * m.macro.mean() + .25 * road
        candidates.append(dict(radius=radius, bus_factor=factor, eligible=eligible, utility=utility))
    best = max((c for c in candidates if c["eligible"]), key=lambda c: c["utility"])
    config = {name: best[name] for name in ["radius", "bus_factor"]}
    bundle = joblib.load(HERE / "robust_g3.joblib")
    bundle.update(name="multiscale_aug_context", context=config)
    model_path = HERE / "context_g3.joblib"
    joblib.dump(bundle, model_path, compress=3)
    selected = {"config": config, "candidates": candidates,
                "model_sha256": hashlib.sha256(model_path.read_bytes()).hexdigest()}
    (OUT / "selection.json").write_text(json.dumps(selected, indent=2), encoding="utf-8")
    print(selected, flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()
