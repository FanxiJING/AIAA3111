"""Select using linked-user folds, then refit the winning candidate."""
import json
import platform

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits

from prepare_data import HERE, KEYS, MODES, ROOT, load, users
from models import cv_groups, metrics_from_cm, point_confusion
from pipeline_v2 import user_folds

PARAMS = dict(max_iter=110, max_leaf_nodes=23, learning_rate=.09, min_samples_leaf=35,
              l2_regularization=2., class_weight="balanced", random_state=42, early_stopping=False)


def aligned(frame, other):
    pd.testing.assert_frame_equal(frame[KEYS], other[KEYS])
    return other


def fit_model(clean, aug, columns, keep, augmented):
    frames = [clean.loc[keep]]
    if augmented:
        frames.append(aug.loc[keep])
    data = pd.concat(frames, ignore_index=True)
    return HistGradientBoostingClassifier(**PARAMS).fit(data[columns], data.label)


def main():
    clean = load("train", "fit_clean")
    aug = aligned(clean, load("train", "fit_aug"))
    meta = load("train", "blind_clean")
    validation = {"clean": meta, **{noise: aligned(meta, load("train", f"blind_{noise}_84221"))
                                     for noise in ("iid", "ou")}}
    columns = [c for c in clean if c not in KEYS]
    keep = clean.n_points.ge(10)
    assert keep.sum() == 70086
    folds = user_folds(clean.loc[keep].reset_index(drop=True))
    split_report = ROOT / "data/splits/report.json"
    assert split_report.is_file()
    train_groups = cv_groups(clean.user_id, split_report)
    test_groups = cv_groups(pd.Series(users("test")), split_report)
    assert set(train_groups).isdisjoint(test_groups)
    # Match pipeline_v2.load_cv_data: a user with no eligible pure windows has no fold.
    in_cv = meta.user_id.isin(folds)
    excluded = sorted(set(meta.loc[~in_cv, "user_id"]))
    results = []
    for fold in range(5):
        fit = keep & clean.user_id.map(folds).ne(fold)
        val = meta.user_id.map(folds).eq(fold)
        assert set(train_groups[fit]).isdisjoint(cv_groups(meta.loc[val, "user_id"], split_report))
        for name in ("multiscale", "multiscale_aug"):
            model = fit_model(clean, aug, columns, fit, name.endswith("_aug"))
            row = {"fold": fold, "candidate": name}
            for noise, df in validation.items():
                pred = model.predict(df.loc[val, columns])
                row[noise] = metrics_from_cm(point_confusion(meta[val], pred, MODES))["macro_f1"]
            results.append(row)
            print(row, flush=True)
    scores = pd.DataFrame(results)
    scores.to_csv(HERE / "cv_folds.csv", index=False)
    means = scores.groupby("candidate")[["clean", "iid", "ou"]].mean()
    eligible = means.clean >= means.clean.max() - .02
    winner = means.loc[eligible, ["iid", "ou"]].mean(axis=1).idxmax()
    config = {"selected": winner, "rule": "within 0.02 of best candidate mean clean fold F1, "
              "then highest mean of iid and OU fold F1", "folds": folds, "params": PARAMS,
              "versions": {"python": platform.python_version(), "sklearn": sklearn.__version__,
                           "numpy": np.__version__, "pandas": pd.__version__},
              "cv_means": means.to_dict("index"), "columns": columns,
              "train_windows": int(keep.sum()), "validation_seed": 84221,
              "no_eligible_train_windows": excluded, "blind_cv_windows": int(in_cv.sum())}
    (HERE / "selection.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    model = fit_model(clean, aug, columns, keep, winner.endswith("_aug"))
    joblib.dump({"estimator": model, "columns": columns, "name": winner},
                HERE / "robust_g3.joblib", compress=3)
    print(f"Refitted {winner} using all {keep.sum()} train windows", flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()
