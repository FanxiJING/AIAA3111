# Offline G3 context experiment

Defined before training-fold scoring. Use the existing robust estimator, its
50-point windows, augmentation and linked-user folds. The decoder averages
window probabilities within a user and quality block. Each neighbour has
weight exp(-abs(midpoint separation in seconds)/240) up to 600 seconds away.
Test radii 0, 2 and 4 in each direction. For a provisional car prediction,
compare bus score times 1, 1.25 or 1.5 with the car score.

Select on five equal-weight training folds. Evaluate natural coordinates and
20 m independent and correlated noise. Allow at most 0.01 loss in any
condition's five-class Macro-F1 and 0.03 in any natural-coordinate class F1
relative to the raw robust model. Maximize 75% mean five-class Macro-F1 plus
25% mean bus/car F1 over the three conditions. Ties favour smaller radius and
then smaller multiplier.

After freezing the winner, replay the previously inspected GeoLife test set
and Go!Track as diagnostics. Fresh external check uses all supported recorded
modes (bus, car, walk and bike) in Medina and Lohan, Zenodo 14712684. Use
valid active NMEA RMC fixes, one observation per time per recording, in their
original cadence. Use the project time and speed block boundaries. Score the
five-way raw robust and selected model on identical points against the folder
mode. Average F1 over supported true modes. Report per-recording denominators
and recall. Plane and ferry fall outside the task. Treat multiple points in a
recording as dependent. Use the release for a single comparison.
