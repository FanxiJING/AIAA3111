"""Predict transportation modes from pre-blocked GeoLife-like point streams."""
import argparse
from pathlib import Path

import joblib
import pandas as pd
from threadpoolctl import threadpool_limits

from features import predict_points


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("points", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--model", type=Path,
                        default=Path(__file__).with_name("robust_g3.joblib"))
    args = parser.parse_args()
    if args.output.exists():
        parser.error(f"Output already exists: {args.output}")
    points = (pd.read_parquet(args.points) if args.points.suffix == ".parquet" else
              pd.read_csv(args.points, dtype={"user_id": str}))
    with threadpool_limits(limits=4):
        out = predict_points(points, joblib.load(args.model))
    if args.output.suffix == ".parquet":
        out.to_parquet(args.output, index=False)
    else:
        out.to_csv(args.output, index=False)


if __name__ == "__main__":
    main()
