"""Fetch only the GPS CSV members of a fixed, stratified Mendeley sample."""
import argparse
import binascii
from concurrent.futures import ThreadPoolExecutor
import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import zipfile
import zlib

API = "https://data.mendeley.com/public-api/datasets/pdpgnn4swh"
MODES = {"02_WALKING": "walk", "03_CAR": "car", "04_BUS": "bus", "05_BICI": "bike"}


def fetch(url, byte_range=None):
    cmd = ["curl", "-fsSL", "--connect-timeout", "10", "--max-time", "100",
           "--retry", "3", "--retry-all-errors"]
    if byte_range:
        cmd.extend(["--range", byte_range])
    return subprocess.check_output([*cmd, url])


def sample():
    chosen = []
    for folder in json.loads(fetch(f"{API}/folders/1")):
        if folder["name"] not in MODES:
            continue
        files = json.loads(fetch(f"{API}/files?folder_id={folder['id']}&version=1"))
        archives = [f for f in files if f["filename"].lower().endswith(".zip")]
        archives.sort(key=lambda f: hashlib.sha256(f["filename"].encode()).digest())
        if len(archives) < 8:
            raise ValueError(folder["name"])
        for f in archives[:8]:
            chosen.append(dict(truth=MODES[folder["name"]], filename=f["filename"],
                               id=f["id"], **{k: f["content_details"][k] for k in
                                              ("download_url", "sha256_hash", "size")}))
    if len(chosen) != 32:
        raise ValueError("Incomplete source listing")
    return chosen


def location_member(f):
    size, url = f["size"], f["download_url"]
    start = max(0, size - 65557)
    tail = fetch(url, f"{start}-{size - 1}")
    if len(tail) not in (size, size - start):
        raise ValueError("Unexpected length for ZIP directory")
    with zipfile.ZipFile(io.BytesIO(tail)) as archive:
        infos = [i for i in archive.infolist() if Path(i.filename).name.lower() == "location.csv"
                 and "__MACOSX" not in i.filename]
        if len(infos) != 1:
            raise ValueError((f["filename"], archive.namelist()))
        info = infos[0]
        if len(tail) == size:
            if hashlib.sha256(tail).hexdigest() != f["sha256_hash"]:
                raise ValueError("Source hash mismatch")
            return archive.read(info)
        offset = info.header_offset + start
        end = min(size - 1, offset + info.compress_size + 131100)
        block = fetch(url, f"{offset}-{end}")
        if len(block) == size:
            block = block[offset:]
        if block[:4] != b"PK\x03\x04":
            raise ValueError("Invalid local header")
        n, extra = struct.unpack_from("<HH", block, 26)
        begin = 30 + n + extra
        data = block[begin:begin + info.compress_size]
        if info.compress_type == zipfile.ZIP_DEFLATED:
            data = zlib.decompress(data, -15)
        if len(data) != info.file_size or binascii.crc32(data) != info.CRC:
            raise ValueError("Invalid GPS member")
        return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dest", type=Path)
    dest = parser.parse_args().dest
    dest.mkdir(parents=True, exist_ok=True)
    manifest = sample()

    def retrieve(f):
        dest_file = dest / (f["id"] + ".csv")
        if not dest_file.exists():
            data = location_member(f)
            tmp = dest_file.with_suffix(".part")
            tmp.write_bytes(data)
            tmp.replace(dest_file)
        f["gps_sha256"] = hashlib.sha256(dest_file.read_bytes()).hexdigest()
        print(f["filename"], dest_file.stat().st_size, flush=True)

    with ThreadPoolExecutor(max_workers=8) as pool:
        list(pool.map(retrieve, manifest))
    (dest / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
