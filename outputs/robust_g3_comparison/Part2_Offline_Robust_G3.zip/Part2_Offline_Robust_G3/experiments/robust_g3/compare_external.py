"""Evaluate five frozen decoders on paired external GPS recordings."""
import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from scipy.stats import rankdata
from sklearn.metrics import confusion_matrix
from threadpoolctl import threadpool_limits

from check_context import SUPPORTED, gotrack, zenodo
from context import contextual_scores, decide
from features import extract, ordered
from prepare_data import HERE, KEYS, MODES, SEEDS, load
from build_windows import assign_windows, window_features
from smoothing import smooth_soft
from models import point_confusion
from select_context import score

METHODS = ["legacy", "legacy_11", "robust", "context", "fusion"]


def point_rows(cm, support, model, source, noise="clean", seed=None):
    np.testing.assert_array_equal(cm.sum(axis=1), support)
    rows = []
    for i, mode in enumerate(MODES):
        rows.append(dict(source=source, noise=noise, seed=seed, model=model, truth=mode,
                         **dict(zip(MODES, cm[i])), total=support[i], correct=cm[i, i],
                         wrong=support[i] - cm[i, i]))
    return rows


def write_point_report(rows, out):
    counts = pd.DataFrame(rows)
    counts["seed"] = counts.seed.astype("Int64")
    counts.to_csv(out / "point_confusions.csv", index=False)
    sources = {"urban": "Urban Routes", "zenodo": "Zenodo", "gotrack": "Go!Track", "geolife": "GeoLife"}
    names = dict(zip(METHODS, ["原始 G3", "原始 G3 + 11 窗平滑", "逐窗鲁棒版", "离线优化版", "新旧融合版"]))
    modes = {"walk": "步行", "bike": "骑行", "bus": "公交", "car": "汽车", "train": "火车"}
    conditions = {"clean": "原始 GPS", "iid": "20 m 独立抖动", "ou": "20 m 连续漂移"}
    lines = ["# 五个 G3 方案的 GPS 点级混淆矩阵", "",
             "按行读取同一真实类别的所有 GPS 点。加粗的预测列数值为判对数，其余预测列为错判去向。",
             "外测使用每趟行程的标签作为该趟各点的真值。真实总数为 0 表示该来源没有该类样本。",
             "GeoLife 扰动实验的每个种子复用同一批点，各种子的点数不能相加当作新的样本量。", ""]
    for (source, noise, seed), group in counts.groupby(["source", "noise", "seed"], dropna=False, sort=False):
        title = f"{sources[source]} · {conditions[noise]}"
        if pd.notna(seed):
            title += f" · 种子 {seed}"
        lines += [f"## {title}", "", "| 真实类别 | 模型 | 真实总数 | 判步行 | 判骑行 | 判公交 | 判汽车 | 判火车 | 判对 | 判错 |",
                  "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for mode in MODES:
            for row in group[group.truth.eq(mode)].itertuples(index=False):
                values = [f"**{getattr(row, c):,}**" if c == mode else f"{getattr(row, c):,}" for c in MODES]
                cells = [modes[mode], names[row.model], f"{row.total:,}", *values, f"{row.correct:,}", f"{row.wrong:,}"]
                lines.append("| " + " | ".join(cells) + " |")
        lines.append("")
    (out / "point_confusions.md").write_text("\n".join(lines), encoding="utf-8")


def urban(folder):
    files = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
    frames, tracks = [], []
    for f in files:
        path = folder / (f["id"] + ".csv")
        if gotrack.digest(path) != f["gps_sha256"]:
            raise ValueError(f["filename"])
        df = pd.read_csv(path, usecols=["time", "latitude", "longitude"], dtype={"time": "Int64"})
        df["timestamp"] = pd.to_datetime(df.pop("time"), unit="ns")
        df["track_id"] = f["id"]
        frames.append(df)
        tracks.append(dict(track_id=f["id"], truth=f["truth"], filename=f["filename"],
                           gps_sha256=f["gps_sha256"], archive_sha256=f["sha256_hash"]))
    points = pd.concat(frames, ignore_index=True)
    points["point_id"] = np.arange(len(points))
    tracks = pd.DataFrame(tracks)
    if not tracks.track_id.is_unique or not tracks.groupby("truth").size().eq(8).all():
        raise ValueError("Invalid trip manifest")
    return points, tracks


def window_predictions(win, features, legacy, bundle):
    model, config = bundle["estimator"], bundle["context"]
    np.testing.assert_array_equal(legacy.classes_, model.classes_)
    classes = model.classes_
    matrix = win[list(legacy.feature_names_in_)].replace([np.inf, -np.inf], np.nan)
    scores = legacy.decision_function(matrix)
    probs = model.predict_proba(features[bundle["columns"]])
    ranks = (rankdata(scores, axis=1) + rankdata(probs, axis=1)) / 2 - 1
    return {
        "legacy": legacy.predict(matrix),
        "legacy_11": smooth_soft(scores, win.feature_block_id, win.start_time, 11, classes),
        "robust": classes[probs.argmax(axis=1)],
        "context": decide(contextual_scores(win, probs, config["radius"]), classes, config["bus_factor"]),
        "fusion": classes[contextual_scores(win, ranks, config["radius"]).argmax(axis=1)],
    }


def classify(points, legacy, bundle):
    outputs = []
    for _, trip in ordered(points).groupby("user_id", sort=False):
        ids = assign_windows(trip, 50, False).to_numpy()
        win = window_features(trip.assign(window_id=ids))
        labels = window_predictions(win, extract(trip, ids), legacy, bundle)
        outputs.append(trip[["point_id", "track_id"]].assign(**{k: p[ids] for k, p in labels.items()}))
    return pd.concat(outputs, ignore_index=True)


def evaluate(raw, tracks, supported, legacy, bundle, source):
    clean, audit = gotrack.prepare(raw)
    preds = classify(clean, legacy, bundle)
    assert preds.point_id.is_unique and set(clean.point_id) == set(preds.point_id)
    assert set(preds.track_id) == set(tracks.track_id)
    df = preds.merge(tracks[["track_id", "truth"]], on="track_id", validate="many_to_one")
    rows = []
    counts = []
    truth_counts = df.truth.value_counts().reindex(MODES, fill_value=0).to_numpy()
    trip_acc = tracks.copy()
    sizes = df.groupby("track_id").size()
    trip_acc["points"] = trip_acc.track_id.map(sizes)
    for name in METHODS:
        cm = confusion_matrix(df.truth, df[name], labels=MODES)
        assert cm.sum() == len(df)
        counts.extend(point_rows(cm, truth_counts, name, source))
        tp = cm.diagonal()
        support = cm.sum(axis=1)
        idx = [MODES.index(c) for c in supported]
        f1 = 2 * tp / (support + cm.sum(axis=0)).clip(1)
        acc = df[name].eq(df.truth).groupby(df.track_id).mean()
        trip_acc[name] = trip_acc.track_id.map(acc)
        rows.append(dict(model=name, points=len(df), trips=len(tracks),
                         macro_f1=f1[idx].mean(), trip_accuracy=acc.mean(),
                         **{c + "_recall": tp[i] / support[i] for c, i in zip(supported, idx)},
                         **{c + "_f1": f1[i] for c, i in zip(supported, idx)}))
    return pd.DataFrame(rows), trip_acc, audit, counts


def geolife(history, legacy, bundle):
    rows = []
    counts = []
    conditions = [("clean", 0)] + [(n, s) for n in ("iid", "ou") for s in SEEDS]
    for noise, seed in conditions:
        if noise == "ou":
            path = history / f"supplementary_experiments/feature_cache/OU30_sigma20_seed{seed}.csv"
        else:
            sigma = 0 if noise == "clean" else 20
            path = history / f"feature_cache/sigma{sigma:02d}_seed{seed}.csv"
        win = pd.read_csv(path, dtype={"user_id": str}, parse_dates=["start_time", "end_time"])
        features = load("test", "blind_clean" if noise == "clean" else f"blind_{noise}_{seed}")
        pd.testing.assert_frame_equal(win[KEYS], features[KEYS], check_dtype=False)
        truth_counts = win[[f"cnt_{c}" for c in MODES]].sum().to_numpy()
        assert truth_counts.sum() == win.n_points.sum()
        for name, pred in window_predictions(win, features, legacy, bundle).items():
            cm = point_confusion(win, pred, MODES)
            counts.extend(point_rows(cm, truth_counts, name, "geolife", noise, None if noise == "clean" else seed))
            rows.append(dict(model=name, noise=noise, seed=seed, **score(win, pred)))
    return pd.DataFrame(rows), counts


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ["urban", "legacy", "zenodo", "gotrack"]:
        parser.add_argument("--" + arg, required=True, type=Path)
    args = parser.parse_args()
    archive = args.legacy / "full.joblib"
    model_path = HERE / "context_g3.joblib"
    frozen = json.loads((HERE / "context_results/selection.json").read_text())
    assert gotrack.digest(model_path) == frozen["model_sha256"]
    assert gotrack.digest(archive) == gotrack.INPUT_HASHES[archive.name]
    legacy, bundle = joblib.load(archive), joblib.load(model_path)
    out = HERE / "urban_results"
    out.mkdir(exist_ok=True)
    raw, tracks = urban(args.urban)
    sources = {"urban": (raw, tracks, SUPPORTED), "zenodo": (*zenodo(args.zenodo)[:2], SUPPORTED)}
    for filename in ("go_track_tracks.csv", "go_track_trackspoints.csv"):
        assert gotrack.digest(args.gotrack / filename) == gotrack.INPUT_HASHES[filename]
    raw = pd.read_csv(args.gotrack / "go_track_trackspoints.csv", parse_dates=["time"]).rename(
        columns={"id": "point_id", "time": "timestamp"})
    tracks = pd.read_csv(args.gotrack / "go_track_tracks.csv").rename(columns={"id": "track_id"})
    tracks["truth"] = tracks.car_or_bus.map({1: "car", 2: "bus"})
    sources["gotrack"] = (raw, tracks[["track_id", "truth"]], gotrack.CLASSES)
    results, summaries, counts = [], {}, []
    for source, (raw, tracks, supported) in sources.items():
        table, trips, audit, source_counts = evaluate(raw, tracks, supported, legacy, bundle, source)
        counts.extend(source_counts)
        if source != "urban":
            reference = "zenodo.json" if source == "zenodo" else "gotrack_replay.json"
            known = json.loads((HERE / "context_results" / reference).read_text())["models"]
            for name, old in known.items():
                np.testing.assert_allclose(table.set_index("model").at[name, "macro_f1"], old["macro_f1"])
        results.append(table.assign(source=source))
        summaries[source] = audit
        trips.to_csv(out / f"{source}_trips.csv", index=False)
        print(source, table[["model", "macro_f1", "bus_recall", "car_recall"]].to_string(index=False), flush=True)
    pd.concat(results, ignore_index=True).to_csv(out / "comparison.csv", index=False)
    (out / "cleaning.json").write_text(json.dumps(summaries, indent=2), encoding="utf-8")
    geo, geo_counts = geolife(args.legacy.parent, legacy, bundle)
    geo.to_csv(out / "geolife_by_seed.csv", index=False)
    write_point_report([*counts, *geo_counts], out)
    print(geo.pivot_table(values="macro", index="model", columns="noise").round(4))


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()
