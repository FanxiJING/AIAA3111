"""Paired point-level evaluation against archived, unsmoothed G3 predictions."""
import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits

from prepare_data import HERE, KEYS, MODES, ROOT, SEEDS, load
from models import cv_groups, metrics_from_cm, point_confusion
from train import aligned


def record(meta, pred, **keys):
    assert set(pred).issubset(MODES)
    cm = point_confusion(meta, pred, MODES)
    metrics = metrics_from_cm(cm)
    return {**keys, "points": cm.sum(), "accuracy": metrics["accuracy"],
            "macro_f1": metrics["macro_f1"], "predicted_train_share": cm.sum(0)[-1] / cm.sum(),
            **dict(zip([f"f1_{mode}" for mode in MODES], metrics["per_class_f1"]))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive-repo", type=Path, default=ROOT)
    args = parser.parse_args()
    history = args.archive_repo / "experiments/noise_feature_smoothing"
    bundle = joblib.load(HERE / "robust_g3.joblib")
    meta = load("test", "blind_clean")[KEYS]
    assert len(meta) == 17380 and meta.n_points.sum() == 860972
    groups = cv_groups(meta.user_id, ROOT / "data/splits/report.json")
    largest = meta.n_points.groupby(groups).sum().idxmax()
    conditions = [("clean", 0, 0)] + [(noise, sigma, seed) for sigma in (5, 10, 20)
                                      for noise in ("iid", "ou") for seed in SEEDS]
    scores, group_scores = [], []
    predictions = meta.copy()
    for noise, sigma, seed in conditions:
        suffix = f"_{sigma}m" if sigma not in (0, 20) else ""
        key = "blind_clean" if not sigma else f"blind_{noise}_{seed}{suffix}"
        frame = aligned(meta, load("test", key))
        tag = f"sigma{sigma:02d}_seed{seed}"
        old_path = (history / f"supplementary_experiments/predictions/G3_originalgamma_OU30_{tag}.csv"
                    if noise == "ou" else history / f"predictions/G3_{tag}_smoothed.csv")
        archive = pd.read_csv(old_path, dtype={"user_id": str}, parse_dates=["start_time", "end_time"])
        pd.testing.assert_frame_equal(meta[KEYS], archive[KEYS], check_dtype=False)
        new = bundle["estimator"].predict(frame[bundle["columns"]])
        predictions[f"{noise}_{tag}"] = pd.Categorical(new, categories=MODES)
        for model, pred in (("G3", archive.S0_raw_k1.to_numpy()), (bundle["name"], new)):
            keys = dict(model=model, noise=noise, sigma=sigma, seed=seed)
            scores.append(record(meta, pred, **keys))
            for group in sorted(set(groups)):
                keep = groups.eq(group)
                group_scores.append(record(meta[keep], pred[keep], group=group, **keys))
            keep = groups.ne(largest)
            group_scores.append(record(meta[keep], pred[keep], group="without_largest", **keys))
    df = pd.DataFrame(scores)
    df.to_csv(HERE / "test_by_seed.csv", index=False)
    pd.DataFrame(group_scores).to_csv(HERE / "test_by_group.csv", index=False)
    table = df.groupby(["model", "noise", "sigma"]).agg(
        seeds=("seed", "size"), macro_f1=("macro_f1", "mean"), sd=("macro_f1", "std"),
        accuracy=("accuracy", "mean"), predicted_train_share=("predicted_train_share", "mean"))
    table.to_csv(HERE / "test_summary.csv")
    predictions.to_parquet(HERE / "test_window_predictions.parquet", index=False)
    print(table.to_string(), flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()
