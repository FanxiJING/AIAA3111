"""Offline window decoding on consecutive windows of each user's GPS block."""
import numpy as np
import pandas as pd


def contextual_scores(meta, scores, radius):
    if radius == 0 or len(meta) < 2:
        return scores.copy()
    keys = meta[["user_id", "feature_block_id", "start_time", "end_time"]].reset_index(drop=True)
    order = keys.sort_values(["user_id", "feature_block_id", "start_time"], kind="stable").index
    keys = keys.iloc[order]
    group = pd.MultiIndex.from_frame(keys[["user_id", "feature_block_id"]]).factorize()[0]
    midpoint = keys.start_time + (keys.end_time - keys.start_time) / 2
    seconds = (midpoint - midpoint.min()).dt.total_seconds().to_numpy()
    probs = scores[order]
    total = probs.copy()
    mass = np.ones(len(keys))
    for lag in range(1, min(radius + 1, len(keys))):
        dt = seconds[lag:] - seconds[:-lag]
        weight = np.where((group[lag:] == group[:-lag]) & (np.abs(dt) <= 600),
                          np.exp(-np.abs(dt) / 240), 0)
        total[lag:] += probs[:-lag] * weight[:, None]
        total[:-lag] += probs[lag:] * weight[:, None]
        mass[lag:] += weight
        mass[:-lag] += weight
    out = np.empty_like(total)
    out[order] = total / mass[:, None]
    return out


def decide(scores, classes, bus_factor):
    classes = np.asarray(classes)
    pred = classes[scores.argmax(axis=1)].copy()
    bus, car = (np.flatnonzero(classes == mode).item() for mode in ("bus", "car"))
    switch = (pred == "car") & (scores[:, bus] * bus_factor > scores[:, car])
    pred[switch] = "bus"
    return pred
