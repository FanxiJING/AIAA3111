# Urban Routes external comparison

Use Urban Routes Dataset v1, DOI 10.17632/pdpgnn4swh.1. Select eight zip
recordings in each supported folder (walk, bike, bus, car), taking the
eight smallest SHA-256 digests of the UTF-8 filename in each folder. This
stratified sample bounds download size. List any unavailable or empty trips.
Use each archive's Location CSV, its original GPS times and the existing
Go!Track cleaning and block rules. Keep the source's trip-level ground truth
separate from feature extraction. Exclude motorcycle. Train stays a possible
prediction. Score Macro-F1 over the four supported modes, point recall per
mode and mean within-trip accuracy. Summarize the trip-level variability.

Freeze five methods before scoring: original G3, original G3 with centered
11-window soft smoothing, robust gradient boosting, its previously selected
offline decoder, and a fixed old/new ensemble. For the ensemble, map the old
SVM decision scores and the new tree probabilities to within-window ranks in
their shared class order (strongest 4, weakest 0, average ties). Take the
equal-weight mean of these ranks, apply the already selected four-window
offline decoder, and choose the strongest class. Ranks avoid interpreting
the SVM scores as calibrated probabilities. No external-data fitting.
Replay the five methods on Go!Track and Zenodo for historical context.
Urban Routes is used for one comparison. These data provide no reference
criterion for railway or timing of transitions between modes.
