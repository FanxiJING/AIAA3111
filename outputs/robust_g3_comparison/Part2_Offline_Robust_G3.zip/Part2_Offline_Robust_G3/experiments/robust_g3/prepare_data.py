"""Build aligned train, blind-validation and fixed-test representations."""
import argparse
import json
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import pandas as pd

from features import ROOT, extract, ordered, window_layout
from build_windows import MODES, assign_windows, read_points

HERE = Path(__file__).resolve().parent
HISTORY = ROOT / "experiments/noise_feature_smoothing"
sys.path.insert(0, str(HISTORY / "supplementary_experiments"))
from run_supplement import displace, ou_field
from run_experiment import SEEDS, perturb

COUNTS = [f"cnt_{m}" for m in MODES]
KEYS = ["user_id", "feature_block_id", "start_time", "end_time", "n_points", "label", *COUNTS]
CACHE = HERE / "cache"


def metadata(points, ids):
    starts, sizes = window_layout(ids)
    counts = pd.crosstab(ids, points["mode"]).reindex(columns=MODES, fill_value=0)
    frame = points.iloc[starts][["user_id", "feature_block_id"]].reset_index(drop=True)
    frame["start_time"] = points.timestamp.to_numpy()[starts]
    frame["end_time"] = points.timestamp.to_numpy()[starts + sizes - 1]
    frame["n_points"] = sizes
    frame["label"] = counts.idxmax(axis=1).to_numpy()
    frame[COUNTS] = counts.to_numpy()
    return frame


def process(task):
    uid, split, folder, moderate_only = task
    points = ordered(read_points(folder / f"{uid}.parquet")).reset_index(drop=True)
    assert points.user_id.eq(uid).all() and points["mode"].isin(MODES).all()
    blind = assign_windows(points, 50, False).to_numpy()
    meta = metadata(points, blind)

    def store(key, features, frame):
        table = pd.concat([frame, features], axis=1)
        table.to_parquet(CACHE / f"{uid}_{key}.parquet", index=False)

    if not moderate_only:
        store("blind_clean", extract(points, blind), meta)
    if split == "train":
        pure = assign_windows(points, 50, True).to_numpy()
        pure_meta = metadata(points, pure)
        store("fit_clean", extract(points, pure), pure_meta)
        # One extra realization per pure window, assigned independently of the label.
        rng = np.random.default_rng([73110, int(uid)])
        sigma = rng.choice([3., 8., 15., 20.], len(pure_meta))[pure]
        iid = np.random.default_rng([73111, int(uid)]).standard_normal((len(points), 2))
        ou = ou_field(points, 73112)
        use_ou = rng.random(len(pure_meta))[pure] < .5
        field = np.where(use_ou[:, None], ou, iid)
        augmented = displace(points, field * sigma[:, None], 1.)
        store("fit_aug", extract(augmented, pure), pure_meta)
    for seed in ([84221] if split == "train" else SEEDS):
        field = ou_field(points, seed)
        sigmas = [20] if split == "train" else ([5, 10] if moderate_only else [5, 10, 20])
        for sigma in sigmas:
            suffix = f"_{sigma}m" if sigma != 20 else ""
            iid, _ = perturb(points, sigma, seed)
            store(f"blind_iid_{seed}{suffix}", extract(iid, blind), meta)
            ou = displace(points, field, sigma)
            store(f"blind_ou_{seed}{suffix}", extract(ou, blind), meta)
    return uid


def users(split):
    return json.loads((ROOT / f"data/splits/{split}_users.json").read_text())


def reference(folder, split, blind):
    suffix = "_blind" if blind else ""
    df = pd.read_csv(folder / f"src/model_training/windows_w50{suffix}.csv",
                     usecols=["split", *KEYS], dtype={"user_id": str},
                     parse_dates=["start_time", "end_time"])
    df = df.loc[df.split.eq(split), KEYS].reset_index(drop=True)
    return df.sort_values(["user_id", "feature_block_id", "start_time"], kind="stable").reset_index(drop=True)


def load(split, key):
    return pd.concat([pd.read_parquet(CACHE / f"{u}_{key}.parquet")
                      for u in sorted(users(split))], ignore_index=True)


def verify(folder, split):
    for key, blind in ([("fit_clean", False), ("blind_clean", True)] if split == "train"
                       else [("blind_clean", False)]):
        actual = load(split, key)[KEYS]
        pd.testing.assert_frame_equal(actual, reference(folder, split, blind),
                                      check_dtype=False, check_like=True)
    print(f"Matched {split} window identities, labels and counts.", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-repo", type=Path, default=ROOT)
    parser.add_argument("--split", choices=["train", "test"], required=True)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--moderate-only", action="store_true",
                        help="Add 5/10 m to an already prepared 20 m test cache")
    args = parser.parse_args()
    if args.moderate_only and args.split != "test":
        parser.error("--moderate-only requires --split test")
    CACHE.mkdir(exist_ok=True)
    tasks = [(u, args.split, args.data_repo / "data/processed/quality_features", args.moderate_only)
             for u in sorted(users(args.split))]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for uid in pool.map(process, tasks):
            print(f"Prepared {args.split} {uid}", flush=True)
    verify(args.data_repo, args.split)


if __name__ == "__main__":
    main()
