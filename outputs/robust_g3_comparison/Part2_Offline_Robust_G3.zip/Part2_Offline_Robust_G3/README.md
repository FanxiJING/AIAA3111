# Part 2 交接：离线鲁棒 G3

Part 2 处理完一段轨迹后，调用根目录的 `predict_offline.py`。它固定加载 `experiments/robust_g3/context_g3.joblib`，给每个 GPS 点返回一个出行方式。权重已训练好，直接用原始经纬度预测即可。下面的命令都在解压后的 `Part2_Offline_Robust_G3` 目录运行。

## 先跑一次示例

已验证的环境为 Windows、Python 3.12.14。首次配置需要安装依赖，之后可以断网预测。

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe predict_offline.py examples/points.csv my_predictions.csv
```

`examples/points.csv` 是合成的 300 个点。把输出的 `predicted_mode` 和 `examples/expected.csv` 按 `point_id` 对齐，可检查接入是否成功。示例的预期值来自冻结模型，仅用于检查运行结果。换自己的数据时，把输入路径和输出路径换掉即可。CSV 与 Parquet 均支持，输出请使用新文件名。

## 接入 Part 2

传入清洗后的 GPS 点表，一个点一行。必需字段如下。

| 列名 | 含义 |
|---|---|
| `user_id` | 用户标识，可以是字符串，例如 `001` |
| `feature_block_id` | 该用户的一段连续轨迹的标识。沿用上游清洗后的块 ID。跨行程或定位中断后使用新的 ID，同一用户内每个独立块的 ID 要唯一 |
| `timestamp` | 采样时间，例如 `2020-01-01 08:00:03`。同一输入采用一致的时区和格式 |
| `latitude` | WGS84 纬度，十进制度，范围 -90 至 90 |
| `longitude` | WGS84 经度，十进制度，范围 -180 至 180 |

上述五列都应有值。模型在用户和连续块内按时间排序，输出恢复输入行序，保留其他输入列并写入 `predicted_mode`。五个取值为 `walk`（步行）、`bike`（骑行）、`bus`（公交）、`car`（汽车）、`train`（火车）。可保留自己的 `point_id`，方便回连 Part 2 的点表。输入只需提供轨迹信息。

在 Python 中接入时，将交接包根目录放在模块搜索路径中，然后把整个连续块一次传入。可以同时传入多个用户和块。

```python
from predict_offline import predict_offline

result = predict_offline(points_df)
```

模型按每窗 50 个点切分。如果块尾剩余不足 25 个点且已有前窗，则将尾部并入前窗。模型在同一用户、同一块内，按时间距离加权参考前后各最多四个窗口，窗口中点最多相距十分钟。因此同一窗内的点共享预测，离线运行应等连续块收齐再调用。

## 结果与报告

| Part 2 要查的内容 | 包内文件 |
|---|---|
| 五种模型的整体表现、适用范围、已知局限 | [实验说明](experiments/robust_g3/README.md) |
| 每个真实类别有多少点判对、判错，以及错去了哪一类 | [中文点级混淆矩阵](experiments/robust_g3/urban_results/point_confusions.md) 和 [CSV](experiments/robust_g3/urban_results/point_confusions.csv) |
| 外测逐模型指标与 GeoLife 逐种子结果 | [外测汇总](experiments/robust_g3/urban_results/comparison.csv) 和 [GeoLife 结果](experiments/robust_g3/urban_results/geolife_by_seed.csv) |
| 训练用户五折、上下文配置和最终权重指纹 | [选型协议](experiments/robust_g3/CONTEXT_PROTOCOL.md) 和 [选型记录](experiments/robust_g3/context_results/selection.json) |

中文混淆矩阵中选“离线优化版”，CSV 的 `model` 列选 `context`。每一行固定一个真实类别，沿预测列横读即可看到错判去向。GeoLife 五类点级 Macro-F1 在原始、20 米独立抖动、20 米连续漂移下依次为 0.8407、0.7587、0.7799。这批 GeoLife 测试用户已多次用于比较，报告中应标为历史复测。Urban Routes 四类外测为 0.4480，其中真实汽车的 8,936 个点全部错分。应按数据来源分别报告。

## 包内实验材料

`experiments/robust_g3/` 保留训练、选型、评估、测试代码和已有结果。该目录内的 `predict.py` 默认使用逐窗鲁棒对照 `robust_g3.joblib`。日常接入请使用包根目录的 `predict_offline.py`。`experiments/noise_feature_smoothing/models/full.joblib` 是原始 G3 对照权重。

复跑训练或历史评估时，另装 `requirements-experiments.txt`，按实验说明准备原始数据、历史窗口表及评估缓存，建议在交接包的副本中运行。模型预测和查看已有结果只需本包。`SHA256SUMS.txt` 中列出了包内各文件的 SHA-256，最终权重也可与选型记录核对。
